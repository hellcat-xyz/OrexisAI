'use strict';

function escapeHtml(value) {
    return String(value)
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

function renderDashboardPage({ user, plans, billing, paymentConfiguration, aiConfiguration = {}, showLoginIntro = false, cspNonce = '' }) {
    const currentPlan = plans.find((plan) => plan.id === billing.currentPlanId) || plans[0];
    const expiryText = billing.planExpiresAt
        ? new Intl.DateTimeFormat('en-US', { dateStyle: 'medium' }).format(new Date(billing.planExpiresAt))
        : '';
    const geminiConfigured = aiConfiguration.isConfigured === true;
    const geminiModel = aiConfiguration.model || 'gemini-3.6-flash';
    const promptLimit = aiConfiguration.promptLimit || { maxCharacters: 131072, maxTokens: 32768, warningRatio: 0.85 };

    return `<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>OrexisAI - Workflow as a Service</title>
    <link rel="stylesheet" href="/style.css">
    <link rel="stylesheet" href="/hyperspeed.css">
    <link rel="stylesheet" href="/orb.css">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body
    data-user-email="${escapeHtml(user.email)}"
    data-original-user-display-name="${escapeHtml(user.displayName)}"
    data-razorpay-key-id="${escapeHtml(paymentConfiguration.razorpay.keyId)}"
    data-razorpay-configured="${paymentConfiguration.razorpay.isConfigured ? 'true' : 'false'}"
    data-paypal-client-id="${escapeHtml(paymentConfiguration.paypal.clientId)}"
    data-paypal-configured="${paymentConfiguration.paypal.isConfigured ? 'true' : 'false'}"
    data-paypal-mode="${escapeHtml(paymentConfiguration.paypal.mode)}"
    data-current-plan-id="${escapeHtml(currentPlan.id)}"
    data-current-plan-name="${escapeHtml(currentPlan.name)}"
    data-plan-expires-at="${escapeHtml(billing.planExpiresAt || '')}"
    data-csp-nonce="${escapeHtml(cspNonce)}"
    data-ai-model="${escapeHtml(geminiModel)}"
    data-prompt-max-characters="${escapeHtml(promptLimit.maxCharacters)}"
    data-prompt-max-tokens="${escapeHtml(promptLimit.maxTokens)}"
    data-prompt-warning-ratio="${escapeHtml(promptLimit.warningRatio)}"
>
    ${showLoginIntro ? renderLoginBrandIntro() : ''}
    <div class="app-container" id="appContainer">
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-brand-row">
                <div class="logo outcome-brand-lockup" aria-label="OrexisAI">
                    <span class="outcome-brand-o" aria-hidden="true">O</span>
                    <span class="outcome-brand-word-mask logo-text" aria-hidden="true">
                        <span class="outcome-brand-word">rexis<span class="outcome-brand-ai">AI</span></span>
                    </span>
                </div>
                <button type="button" class="sidebar-toggle" id="sidebarToggle" aria-label="Collapse sidebar" aria-expanded="true">
                    <i class="fa-solid fa-angles-left" aria-hidden="true"></i>
                </button>
            </div>

            <nav class="nav-menu" aria-label="Main navigation">
                <button type="button" class="nav-item active" data-view-target="hub" aria-label="Hub">
                    <i class="fa-solid fa-border-all" aria-hidden="true"></i>
                    <span class="nav-label">Hub</span>
                </button>
                <button type="button" class="nav-item" data-view-target="agent" aria-label="AI Agent">
                    <i class="fa-solid fa-message" aria-hidden="true"></i>
                    <span class="nav-label">AI Agent</span>
                </button>
                <button type="button" class="nav-item" data-view-target="marketing" aria-label="Marketing">
                    <i class="fa-solid fa-bullhorn" aria-hidden="true"></i>
                    <span class="nav-label">Marketing</span>
                </button>
                <button type="button" class="nav-item" data-view-target="analytics" aria-label="Analytics">
                    <i class="fa-solid fa-chart-line" aria-hidden="true"></i>
                    <span class="nav-label">Analytics</span>
                </button>
                <button type="button" class="nav-item" data-view-target="crm" aria-label="CRM">
                    <i class="fa-solid fa-users" aria-hidden="true"></i>
                    <span class="nav-label">CRM</span>
                </button>
            </nav>

            <section class="chat-history-panel" aria-label="AI agent chat actions">
                <button type="button" class="new-chat-button" id="newChatButton">
                    <i class="fa-solid fa-pen-to-square" aria-hidden="true"></i>
                    <span>New chat</span>
                </button>
                <button type="button" class="recent-chats-button" id="recentChatsButton" aria-haspopup="dialog" aria-controls="recentChatsModal" aria-expanded="false">
                    <i class="fa-solid fa-clock-rotate-left" aria-hidden="true"></i>
                    <span class="recent-chats-button-copy">
                        <strong>Recent chats</strong>
                        <small>Open saved conversations</small>
                    </span>
                    <span class="recent-chats-count" id="recentChatsCount" aria-label="0 saved chats">0</span>
                    <i class="fa-solid fa-chevron-right recent-chats-chevron" aria-hidden="true"></i>
                </button>
            </section>

            <button type="button" class="nav-item upgrade-nav-item sidebar-upgrade-button" id="upgradeButton" aria-label="Upgrade plan">
                <i class="fa-solid fa-crown" aria-hidden="true"></i>
                <span class="nav-label">Upgrade</span>
                <span class="upgrade-pill">${escapeHtml(currentPlan.name)}</span>
            </button>

            <div class="sidebar-footer">
                <div class="profile-menu" id="profileMenu" role="menu" aria-hidden="true">
                    <div class="profile-menu-heading">
                        <strong data-user-display-name>${escapeHtml(user.displayName)}</strong>
                        <span>${escapeHtml(user.email)}</span>
                    </div>
                    <button type="button" class="profile-menu-item" data-view-target="settings" role="menuitem">
                        <i class="fa-solid fa-gear" aria-hidden="true"></i>
                        <span>Account settings</span>
                    </button>
                    <button type="button" class="profile-menu-item" id="profileUpgradeButton" role="menuitem">
                        <i class="fa-solid fa-crown" aria-hidden="true"></i>
                        <span>Plans and billing</span>
                    </button>
                    <form method="post" action="/logout">
                        <button class="profile-menu-item danger" type="submit" role="menuitem">
                            <i class="fa-solid fa-arrow-right-from-bracket" aria-hidden="true"></i>
                            <span>Sign out</span>
                        </button>
                    </form>
                </div>

                <button type="button" class="user-profile" id="profileButton" aria-haspopup="menu" aria-expanded="false" aria-controls="profileMenu">
                    <span class="avatar">${escapeHtml(user.initials)}</span>
                    <span class="user-info">
                        <span class="name" data-user-display-name>${escapeHtml(user.displayName)}</span>
                        <span class="plan" id="currentPlanName">${escapeHtml(currentPlan.name)} plan</span>
                    </span>
                    <i class="fa-solid fa-chevron-up profile-chevron" aria-hidden="true"></i>
                </button>
            </div>
        </aside>

        <main class="main-content">
            <header class="top-bar">
                <div class="page-heading">
                    <span class="page-kicker" id="pageKicker">Outcome workspace</span>
                    <h1 id="pageTitle">Ready-to-Run Outcomes</h1>
                    <p id="pageSubtitle">Choose a business result. OrexisAI handles the models, tools, and routing behind it.</p>
                </div>
                <div class="topbar-actions">
                    <div class="search-bar">
                        <i class="fa-solid fa-search" aria-hidden="true"></i>
                        <input id="workspaceSearch" type="search" placeholder="Search outcomes..." aria-label="Search current workspace">
                        <button type="button" class="search-clear" id="clearSearchButton" aria-label="Clear search" hidden>
                            <i class="fa-solid fa-xmark" aria-hidden="true"></i>
                        </button>
                    </div>
                </div>
            </header>

            <div class="search-empty-state" id="searchEmptyState" hidden>
                <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
                <strong>No matching items</strong>
                <span>Try a broader search in this workspace.</span>
            </div>

            <section class="dashboard-view agent-view" data-view="agent" aria-label="AI Agent chat" hidden>
                <div class="agent-chat-shell">
                    <div class="agent-orb-background" id="outcomeAgentOrb" aria-hidden="true"></div>
                    <header class="agent-chat-header">
                        <div class="agent-chat-heading">
                            <span class="agent-status-dot" aria-hidden="true"></span>
                            <div>
                                <span class="section-label">OrexisAI agent</span>
                                <h2 id="activeChatTitle">New chat</h2>
                                <form class="chat-title-editor" id="chatTitleEditor" hidden>
                                    <input id="chatTitleInput" type="text" maxlength="80" aria-label="Chat title">
                                    <button type="submit" aria-label="Save chat title"><i class="fa-solid fa-check" aria-hidden="true"></i></button>
                                    <button type="button" id="cancelChatRenameButton" aria-label="Cancel rename"><i class="fa-solid fa-xmark" aria-hidden="true"></i></button>
                                </form>
                            </div>
                        </div>
                        <div class="agent-chat-actions">
                            <span class="gemini-status-badge ${geminiConfigured ? 'connected' : 'setup-required'}" title="${escapeHtml(geminiModel)}">
                                <i class="fa-solid ${geminiConfigured ? 'fa-wand-magic-sparkles' : 'fa-triangle-exclamation'}" aria-hidden="true"></i>
                                ${geminiConfigured ? `Gemini · ${escapeHtml(geminiModel)}` : 'Gemini setup required'}
                            </span>
                            <span class="database-saved-badge"><i class="fa-solid fa-database" aria-hidden="true"></i> PostgreSQL</span>
                            <button type="button" class="icon-action" id="renameChatButton" aria-label="Rename chat" title="Rename chat" disabled>
                                <i class="fa-solid fa-pen" aria-hidden="true"></i>
                            </button>
                            <button type="button" class="icon-action danger" id="deleteChatButton" aria-label="Delete chat" title="Delete chat" disabled>
                                <i class="fa-solid fa-trash" aria-hidden="true"></i>
                            </button>
                        </div>
                    </header>

                    <div class="agent-message-list" id="agentMessageList" role="log" aria-live="polite" aria-relevant="additions">
                        <div class="agent-empty-state" id="agentEmptyState">
                            <span class="agent-empty-icon"><i class="fa-solid fa-wand-magic-sparkles" aria-hidden="true"></i></span>
                            <h3>What outcome should the agent handle?</h3>
                            <p>Type a complete instruction. Every command and Gemini reply is attached to this account and stored in PostgreSQL, so you can reopen the full conversation from the sidebar.</p>
                            <div class="agent-prompt-suggestions" aria-label="Command examples">
                                <button type="button" data-agent-suggestion="Create next week's marketing plan from my best-selling products and prepare the social copy.">Plan next week’s marketing</button>
                                <button type="button" data-agent-suggestion="Analyze this week's performance and tell me the three actions with the highest impact.">Analyze business performance</button>
                                <button type="button" data-agent-suggestion="Find customers who need a follow-up and draft a personalized message for each one.">Prepare CRM follow-ups</button>
                            </div>
                        </div>
                    </div>

                    <form class="agent-command-composer" id="agentCommandForm">
                        <div class="agent-upload-toolbar" aria-label="Upload options">
                            <button type="button" class="agent-upload-button" id="agentCameraButton" aria-haspopup="dialog" aria-controls="cameraModal">
                                <i class="fa-solid fa-camera" aria-hidden="true"></i>
                                <span>Camera</span>
                            </button>
                            <button type="button" class="agent-upload-button" id="agentFolderButton">
                                <i class="fa-solid fa-folder-arrow-up" aria-hidden="true"></i>
                                <span>Folder</span>
                            </button>
                            <span class="agent-upload-status" id="agentUploadStatus" role="status" aria-live="polite"></span>
                            <input id="agentCameraCaptureInput" type="file" accept="image/*" capture="environment" hidden>
                            <input id="agentFolderInput" type="file" webkitdirectory directory multiple hidden>
                        </div>
                        <div class="agent-attachment-list" id="agentAttachmentList" aria-label="Uploaded attachments" hidden></div>
                        <label class="sr-only" for="agentCommandInput">Command the OrexisAI agent</label>
                        <textarea id="agentCommandInput" name="command" rows="1" placeholder="Message OrexisAI…" autocomplete="off" aria-describedby="agentPromptLimitStatus"></textarea>
                        <button type="submit" class="agent-send-button" id="agentSendButton" aria-label="Send command" disabled>
                            <i class="fa-solid fa-arrow-up" aria-hidden="true"></i>
                        </button>
                        <div class="agent-composer-meta">
                            <span><i class="fa-solid fa-lock" aria-hidden="true"></i> Private to your account</span>
                            <span id="agentPromptLimitStatus" class="agent-prompt-limit" aria-live="polite">0 / ${escapeHtml(promptLimit.maxCharacters.toLocaleString('en-US'))}</span>
                            <span>Enter to send · Shift+Enter for a new line</span>
                        </div>
                    </form>
                </div>
            </section>

            <section class="dashboard-view active" data-view="hub" aria-label="Outcome Hub">
                <div class="outcome-hero searchable-item" data-search-text="workflow as a service outcomes automation business hub">
                    <div class="hyperspeed-background" id="outcomeHyperspeed" aria-hidden="true"></div>
                    <div class="outcome-hero-copy">
                        <span class="eyebrow"><i class="fa-solid fa-wand-magic-sparkles" aria-hidden="true"></i> Workflow-as-a-Service</span>
                        <h2>AI is hidden. The finished work is what you buy.</h2>
                        <p>Run pre-built, multi-step business workflows without choosing models or stitching tools together. OrexisAI routes each step to the best available system and returns a usable result.</p>
                        <div class="hero-actions">
                            <button class="primary-action run-btn" type="button" data-workflow="marketing">
                                Run weekly marketing <i class="fa-solid fa-play" aria-hidden="true"></i>
                            </button>
                            <button class="secondary-action" type="button" data-view-target="analytics">
                                View business pulse <i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
                            </button>
                        </div>
                    </div>
                    <div class="outcome-route" aria-label="Example workflow routing">
                        <div class="route-node source"><i class="fa-solid fa-store" aria-hidden="true"></i><span>Your business data</span></div>
                        <div class="route-line"></div>
                        <div class="route-stack">
                            <div class="route-node"><i class="fa-solid fa-chart-simple" aria-hidden="true"></i><span>Analyze sales</span></div>
                            <div class="route-node"><i class="fa-solid fa-pen-nib" aria-hidden="true"></i><span>Create campaign</span></div>
                            <div class="route-node"><i class="fa-solid fa-image" aria-hidden="true"></i><span>Generate assets</span></div>
                        </div>
                        <div class="route-line"></div>
                        <div class="route-node result"><i class="fa-solid fa-circle-check" aria-hidden="true"></i><span>Finished outcome</span></div>
                    </div>
                </div>

                <div class="pulse-grid" aria-label="Workspace summary">
                    <article class="pulse-card searchable-item" data-search-text="active workflows automation">
                        <span>Active workflows</span>
                        <strong>4</strong>
                        <small><i class="fa-solid fa-arrow-trend-up" aria-hidden="true"></i> 2 ready to run</small>
                    </article>
                    <article class="pulse-card searchable-item" data-search-text="hours saved productivity">
                        <span>Estimated time saved</span>
                        <strong>11.4h</strong>
                        <small>This week</small>
                    </article>
                    <article class="pulse-card searchable-item" data-search-text="outcomes completed success">
                        <span>Outcomes completed</span>
                        <strong>18</strong>
                        <small>94% completed without edits</small>
                    </article>
                </div>

                <div class="section-heading">
                    <div>
                        <span class="section-label">Outcome library</span>
                        <h2>One click, complete work</h2>
                    </div>
                </div>
                <div class="workflows-grid" aria-label="Available workflows">
                    ${renderWorkflowCard({ icon: 'fa-rocket', gradient: 'gradient-1', title: 'Weekly Marketing', description: 'Calculates this week’s real sales performance and creates a fact-grounded marketing plan.', time: 'Live data', workflow: 'weekly-marketing', search: 'weekly marketing revenue orders customers products' })}
                    ${renderWorkflowCard({ icon: 'fa-magnifying-glass-dollar', gradient: 'gradient-2', title: 'Competitor Audit', description: 'Analyzes the newest sourced competitor snapshots from your configured integrations.', time: 'Source dependent', workflow: 'competitor-audit', search: 'competitor audit pricing offers positioning sources' })}
                    ${renderWorkflowCard({ icon: 'fa-star-half-stroke', gradient: 'gradient-3', title: 'Review Responder', description: 'Uses real unanswered reviews to create editable, provider-safe response drafts.', time: 'Up to 20 reviews', workflow: 'review-responder', search: 'review responder customer reputation replies real reviews' })}
                    ${renderWorkflowCard({ icon: 'fa-box-open', gradient: 'gradient-4', title: 'Inventory Predictor', description: 'Forecasts next week\'s inventory needs based on weather, holidays, and past sales.', time: '~1 min', workflow: 'inventory', search: 'inventory forecast demand weather sales' })}
                </div>
            </section>

            <section class="dashboard-view" data-view="marketing" aria-label="Marketing workspace" hidden>
                <div class="workspace-grid marketing-layout">
                    <article class="command-card searchable-item" data-search-text="weekly marketing real revenue orders customers products">
                        <div class="command-card-icon marketing"><i class="fa-solid fa-bullhorn" aria-hidden="true"></i></div>
                        <span class="section-label">Database-backed workflow</span>
                        <h2>Run this week’s marketing</h2>
                        <p>OrexisAI fetches the newest valid orders, customers, products, and campaign records, calculates the current and previous comparable periods, then asks the AI layer to reason only over those verified facts.</p>
                        <ul class="deliverable-list">
                            <li><i class="fa-solid fa-check" aria-hidden="true"></i> Revenue, orders, AOV, and customer metrics</li>
                            <li><i class="fa-solid fa-check" aria-hidden="true"></i> Top products and period comparison</li>
                            <li><i class="fa-solid fa-check" aria-hidden="true"></i> Fact-grounded recommendations and weekly plan</li>
                        </ul>
                        <button class="primary-action run-btn" type="button" data-workflow="weekly-marketing">Run weekly marketing <i class="fa-solid fa-play" aria-hidden="true"></i></button>
                    </article>

                    <article class="activity-panel searchable-item" data-search-text="marketing current data status records period">
                        <div class="panel-heading">
                            <div><span class="section-label">Current data</span><h3>Marketing performance</h3></div>
                            <button class="secondary-action business-data-refresh" type="button" data-refresh-view="marketing"><i class="fa-solid fa-rotate" aria-hidden="true"></i> Refresh</button>
                        </div>
                        <div class="business-data-status" id="marketingDataStatus" role="status" aria-live="polite">Loading current database values…</div>
                        <div class="metrics-grid embedded-metrics" id="marketingMetricsGrid" aria-label="Marketing metrics"></div>
                    </article>
                </div>

                <div class="analytics-grid business-data-grid">
                    <article class="chart-panel searchable-item" data-search-text="revenue trend real chart">
                        <div class="panel-heading"><div><span class="section-label">Revenue trend</span><h3 id="marketingTrendTitle">Selected period</h3></div></div>
                        <div class="bar-chart" id="marketingTrendChart" aria-label="Revenue by day"></div>
                    </article>
                    <article class="activity-panel searchable-item" data-search-text="top products real sales volume">
                        <div class="panel-heading"><div><span class="section-label">Top products</span><h3>Verified product performance</h3></div></div>
                        <div class="activity-list" id="marketingTopProducts"></div>
                    </article>
                </div>

                <div class="workspace-grid marketing-layout">
                    <article class="activity-panel searchable-item" data-search-text="campaign conversion acquisition retention data availability">
                        <div class="panel-heading"><div><span class="section-label">Campaign data</span><h3>Connected performance</h3></div></div>
                        <div id="marketingCampaignPanel" class="business-result-panel"></div>
                    </article>
                    <article class="command-card searchable-item" data-search-text="competitor audit legitimate source pricing offers">
                        <div class="command-card-icon marketing"><i class="fa-solid fa-magnifying-glass-dollar" aria-hidden="true"></i></div>
                        <span class="section-label">Sourced competitor workflow</span>
                        <h3>Audit configured competitors</h3>
                        <p>Uses only the newest snapshots imported from legitimate APIs or connected sources. Missing integrations are reported instead of replaced with fabricated information.</p>
                        <button class="primary-action run-btn" type="button" data-workflow="competitor-audit">Run competitor audit <i class="fa-solid fa-play" aria-hidden="true"></i></button>
                    </article>
                </div>
            </section>

            <section class="dashboard-view" data-view="analytics" aria-label="Analytics workspace" hidden>
                <form class="analytics-filter glass-panel" id="analyticsDateForm">
                    <div><span class="section-label">Dynamic date range</span><h2>Analytics &amp; Decisions</h2></div>
                    <label>From<input type="date" name="from" id="analyticsFromDate"></label>
                    <label>To<input type="date" name="to" id="analyticsToDate"></label>
                    <button class="secondary-action" type="submit"><i class="fa-solid fa-filter" aria-hidden="true"></i> Apply</button>
                    <button class="secondary-action" type="button" data-refresh-view="analytics"><i class="fa-solid fa-rotate" aria-hidden="true"></i> Refresh</button>
                </form>
                <div class="business-data-status" id="analyticsDataStatus" role="status" aria-live="polite">Loading current database values…</div>
                <div class="metrics-grid" id="analyticsMetricsGrid" aria-label="Business metrics"></div>

                <div class="analytics-grid">
                    <article class="chart-panel searchable-item" data-search-text="sales trend chart revenue real database">
                        <div class="panel-heading">
                            <div><span class="section-label">Sales trend</span><h3 id="analyticsTrendTitle">Selected period</h3></div>
                            <span class="status-badge" id="analyticsRecordsBadge">0 records</span>
                        </div>
                        <div class="bar-chart" id="analyticsTrendChart" aria-label="Sales chart for selected period"></div>
                    </article>

                    <article class="insight-panel searchable-item" data-search-text="inventory predictor sales velocity stock depletion">
                        <div class="insight-icon"><i class="fa-solid fa-box-open" aria-hidden="true"></i></div>
                        <span class="section-label">Database-backed prediction</span>
                        <h3>Calculate inventory risk from actual units sold.</h3>
                        <p>Uses current stock, verified order items, configured lead times, and a transparent 28-day methodology. Products with missing inputs are marked insufficient instead of guessed.</p>
                        <button class="secondary-action run-btn" type="button" data-workflow="inventory-predictor">Run inventory predictor <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></button>
                    </article>
                </div>

                <article class="activity-panel business-wide-panel searchable-item" data-search-text="calculation methodology data availability">
                    <div class="panel-heading"><div><span class="section-label">Traceability</span><h3>Calculation and data availability</h3></div></div>
                    <div id="analyticsAvailabilityPanel" class="business-result-panel"></div>
                </article>
            </section>

            <section class="dashboard-view" data-view="crm" aria-label="CRM workspace" hidden>
                <div class="section-heading">
                    <div><span class="section-label">Customer database</span><h2>CRM</h2></div>
                    <button class="secondary-action business-data-refresh" type="button" data-refresh-view="crm"><i class="fa-solid fa-rotate" aria-hidden="true"></i> Refresh</button>
                </div>
                <div class="business-data-status" id="crmDataStatus" role="status" aria-live="polite">Loading current database values…</div>
                <div class="metrics-grid crm-metrics" id="crmMetricsGrid" aria-label="Customer metrics"></div>

                <div class="crm-layout">
                    <article class="customer-panel searchable-item" data-search-text="customer list contacts follow up loyalty actual records">
                        <div class="panel-heading">
                            <div><span class="section-label">Priority customers</span><h3>Verified customer activity</h3></div>
                        </div>
                        <div class="customer-table" id="crmCustomerTable" role="table" aria-label="Priority customers"></div>
                    </article>

                    <article class="crm-action-panel searchable-item" data-search-text="review responder real customer reviews">
                        <div class="command-card-icon crm"><i class="fa-solid fa-star-half-stroke" aria-hidden="true"></i></div>
                        <span class="section-label">Review workflow</span>
                        <h3>Respond to real customer reviews</h3>
                        <p>Retrieves unanswered reviews, detects sentiment and concerns, and creates editable drafts. Sending remains disabled unless a real review-provider endpoint is configured.</p>
                        <button class="primary-action run-btn" type="button" data-workflow="review-responder">Prepare review responses <i class="fa-solid fa-play" aria-hidden="true"></i></button>
                    </article>
                </div>
            </section>

            <section class="dashboard-view" data-view="settings" aria-label="Account settings" hidden>
                <div class="settings-search-results" id="settingsSearchResults" hidden>
                    <div class="settings-search-heading">
                        <div>
                            <span class="section-label">Settings search</span>
                            <h2>Matching controls</h2>
                        </div>
                        <span class="settings-result-count" id="settingsSearchResultCount">0 results</span>
                    </div>
                    <div class="settings-search-list" id="settingsSearchResultsList" role="list"></div>
                </div>

                <form class="settings-form-shell" id="workspaceSettingsForm">
                    <div class="settings-layout">
                        <article class="settings-card profile-settings-card" id="settings-profile-summary">
                            <div class="large-avatar">${escapeHtml(user.initials)}</div>
                            <div>
                                <span class="section-label">Your profile</span>
                                <h2 data-user-display-name>${escapeHtml(user.displayName)}</h2>
                                <p>${escapeHtml(user.email)}</p>
                            </div>
                            <div class="settings-plan-card">
                                <span>Current plan</span>
                                <strong data-current-plan-name>${escapeHtml(currentPlan.name)}</strong>
                                <small data-current-plan-expiry>${expiryText ? `Active until ${escapeHtml(expiryText)}` : 'No expiry'}</small>
                                <button type="button" class="secondary-action" id="settingsUpgradeButton">Manage billing</button>
                            </div>
                        </article>

                        <article class="settings-card settings-card-wide" id="settings-user-preferences" data-setting-section="User preferences">
                            <div class="panel-heading">
                                <div><span class="section-label">Personalization</span><h3>User preferences</h3></div>
                                <span class="settings-section-icon"><i class="fa-solid fa-user-gear" aria-hidden="true"></i></span>
                            </div>
                            <p class="settings-description">Customize how your account is identified and how information is formatted for you.</p>
                            <div class="form-grid settings-form-grid">
                                <label class="setting-control" id="setting-display-name" data-setting-item data-setting-title="Display name" data-setting-category="User preferences" data-setting-description="Change the name shown in your profile menu and settings.">
                                    <span>Display name</span>
                                    <input type="text" name="displayName" value="${escapeHtml(user.displayName)}" maxlength="60" autocomplete="name">
                                    <small>Shown locally in this dashboard.</small>
                                </label>
                                <label class="setting-control" id="setting-role" data-setting-item data-setting-title="Role or job title" data-setting-category="User preferences" data-setting-description="Set your role so workspace recommendations fit your responsibilities.">
                                    <span>Role or job title</span>
                                    <input type="text" name="role" placeholder="Owner, marketer, operations lead">
                                    <small>Used to tailor workflow suggestions.</small>
                                </label>
                                <label class="setting-control" id="setting-language" data-setting-item data-setting-title="Language" data-setting-category="User preferences" data-setting-description="Choose the language used for generated outcomes and summaries.">
                                    <span>Outcome language</span>
                                    <select name="language">
                                        <option value="en-US">English (US)</option>
                                        <option value="en-GB">English (UK)</option>
                                        <option value="hi-IN">Hindi</option>
                                        <option value="es-ES">Spanish</option>
                                        <option value="fr-FR">French</option>
                                    </select>
                                    <small>Applies to future generated content.</small>
                                </label>
                                <label class="setting-control" id="setting-timezone" data-setting-item data-setting-title="Time zone" data-setting-category="User preferences" data-setting-description="Control dates, schedules, and workflow completion times.">
                                    <span>Time zone</span>
                                    <select name="timezone">
                                        <option value="Asia/Kolkata">Asia/Kolkata</option>
                                        <option value="UTC">UTC</option>
                                        <option value="America/New_York">America/New_York</option>
                                        <option value="America/Los_Angeles">America/Los_Angeles</option>
                                        <option value="Europe/London">Europe/London</option>
                                        <option value="Asia/Singapore">Asia/Singapore</option>
                                    </select>
                                    <small>Used for schedules and timestamps.</small>
                                </label>
                                <label class="setting-control" id="setting-date-format" data-setting-item data-setting-title="Date format" data-setting-category="User preferences" data-setting-description="Choose how dates are displayed across the dashboard.">
                                    <span>Date format</span>
                                    <select name="dateFormat">
                                        <option value="medium">Jul 25, 2026</option>
                                        <option value="numeric-us">07/25/2026</option>
                                        <option value="numeric-eu">25/07/2026</option>
                                        <option value="iso">2026-07-25</option>
                                    </select>
                                    <small>Controls dashboard date formatting.</small>
                                </label>
                                <label class="setting-control" id="setting-default-workspace" data-setting-item data-setting-title="Default workspace" data-setting-category="User preferences" data-setting-description="Choose which workspace opens after your next sign-in or refresh.">
                                    <span>Default workspace</span>
                                    <select name="defaultWorkspace">
                                        <option value="hub">Hub</option>
                                        <option value="agent">AI Agent</option>
                                        <option value="marketing">Marketing</option>
                                        <option value="analytics">Analytics</option>
                                        <option value="crm">CRM</option>
                                    </select>
                                    <small>Used the next time the dashboard loads.</small>
                                </label>
                            </div>
                        </article>

                        <article class="settings-card settings-card-wide" id="settings-appearance" data-setting-section="Appearance">
                            <div class="panel-heading">
                                <div><span class="section-label">Site customization</span><h3>Appearance</h3></div>
                                <span class="settings-section-icon"><i class="fa-solid fa-palette" aria-hidden="true"></i></span>
                            </div>
                            <p class="settings-description">Preview appearance changes instantly. Save them when the dashboard feels right.</p>

                            <fieldset class="setting-group" id="setting-theme" data-setting-item data-setting-title="Theme" data-setting-category="Appearance" data-setting-description="Switch the site between dark, midnight, and light themes.">
                                <legend>Theme</legend>
                                <div class="theme-choice-grid">
                                    <label class="theme-choice"><input type="radio" name="theme" value="dark" checked><span class="theme-preview dark-preview"><i></i><i></i><i></i></span><strong>Dark</strong></label>
                                    <label class="theme-choice"><input type="radio" name="theme" value="midnight"><span class="theme-preview midnight-preview"><i></i><i></i><i></i></span><strong>Midnight</strong></label>
                                    <label class="theme-choice"><input type="radio" name="theme" value="light"><span class="theme-preview light-preview"><i></i><i></i><i></i></span><strong>Light</strong></label>
                                </div>
                            </fieldset>

                            <fieldset class="setting-group" id="setting-accent-color" data-setting-item data-setting-title="Accent color" data-setting-category="Appearance" data-setting-description="Change buttons, active navigation, links, and focus highlights.">
                                <legend>Accent color</legend>
                                <div class="accent-choice-row">
                                    <label class="accent-choice indigo" title="Indigo"><input type="radio" name="accentColor" value="indigo" checked><span></span></label>
                                    <label class="accent-choice blue" title="Blue"><input type="radio" name="accentColor" value="blue"><span></span></label>
                                    <label class="accent-choice emerald" title="Emerald"><input type="radio" name="accentColor" value="emerald"><span></span></label>
                                    <label class="accent-choice rose" title="Rose"><input type="radio" name="accentColor" value="rose"><span></span></label>
                                    <label class="accent-choice amber" title="Amber"><input type="radio" name="accentColor" value="amber"><span></span></label>
                                </div>
                            </fieldset>

                            <div class="form-grid settings-form-grid appearance-selects">
                                <label class="setting-control" id="setting-density" data-setting-item data-setting-title="Dashboard density" data-setting-category="Appearance" data-setting-description="Choose comfortable or compact spacing throughout the site.">
                                    <span>Dashboard density</span>
                                    <select name="density"><option value="comfortable">Comfortable</option><option value="compact">Compact</option></select>
                                </label>
                                <label class="setting-control" id="setting-text-size" data-setting-item data-setting-title="Text size" data-setting-category="Appearance" data-setting-description="Make dashboard text smaller, standard, or larger.">
                                    <span>Text size</span>
                                    <select name="textSize"><option value="small">Small</option><option value="standard" selected>Standard</option><option value="large">Large</option></select>
                                </label>
                                <label class="setting-control" id="setting-card-style" data-setting-item data-setting-title="Card style" data-setting-category="Appearance" data-setting-description="Choose glass, solid, or minimal cards for the site.">
                                    <span>Card style</span>
                                    <select name="cardStyle"><option value="glass">Glass</option><option value="solid">Solid</option><option value="minimal">Minimal</option></select>
                                </label>
                                <label class="setting-control" id="setting-corner-style" data-setting-item data-setting-title="Corner style" data-setting-category="Appearance" data-setting-description="Change cards and controls between rounded and sharp corners.">
                                    <span>Corner style</span>
                                    <select name="cornerStyle"><option value="rounded">Rounded</option><option value="soft">Soft</option><option value="sharp">Sharp</option></select>
                                </label>
                            </div>

                            <div class="preference-list compact-preference-list">
                                <label class="toggle-row" id="setting-reduce-motion" data-setting-item data-setting-title="Reduce animations" data-setting-category="Appearance" data-setting-description="Reduce motion and nonessential interface animations."><span><strong>Reduce animations</strong><small>Turns off most motion and transition effects.</small></span><input type="checkbox" name="reduceMotion"><span class="toggle-control"></span></label>
                                <label class="toggle-row" id="setting-high-contrast" data-setting-item data-setting-title="High contrast" data-setting-category="Appearance" data-setting-description="Increase borders and text contrast for clearer visibility."><span><strong>High contrast</strong><small>Makes controls and card boundaries easier to see.</small></span><input type="checkbox" name="highContrast"><span class="toggle-control"></span></label>
                                <label class="toggle-row" id="setting-sidebar-default" data-setting-item data-setting-title="Collapsed sidebar by default" data-setting-category="Appearance" data-setting-description="Start the dashboard with the sidebar hidden to create more workspace room."><span><strong>Collapse sidebar by default</strong><small>Uses the compact sidebar whenever the dashboard loads.</small></span><input type="checkbox" name="sidebarDefaultCollapsed"><span class="toggle-control"></span></label>
                            </div>
                        </article>

                        <article class="settings-card settings-form" id="settings-business-context" data-setting-section="Business context">
                            <div class="panel-heading">
                                <div><span class="section-label">Workspace defaults</span><h3>Business context</h3></div>
                                <span class="settings-section-icon"><i class="fa-solid fa-briefcase" aria-hidden="true"></i></span>
                            </div>
                            <p class="settings-description">These details help workflows produce more relevant outcomes.</p>
                            <div class="form-grid settings-form-grid single-column-grid">
                                <label class="setting-control" id="setting-business-name" data-setting-item data-setting-title="Business name" data-setting-category="Business context" data-setting-description="Set the business name used in generated work."><span>Business name</span><input type="text" name="businessName" placeholder="Your business name" autocomplete="organization"></label>
                                <label class="setting-control" id="setting-industry" data-setting-item data-setting-title="Industry" data-setting-category="Business context" data-setting-description="Choose your industry to improve recommendations and examples."><span>Industry</span><select name="industry"><option value="">Choose an industry</option><option>Food and beverage</option><option>Retail</option><option>Professional services</option><option>Health and wellness</option><option>Other</option></select></label>
                                <label class="setting-control" id="setting-primary-market" data-setting-item data-setting-title="Primary market" data-setting-category="Business context" data-setting-description="Describe the city, region, or customer segment your business serves."><span>Primary market</span><input type="text" name="market" placeholder="City or customer segment"></label>
                                <label class="setting-control" id="setting-weekly-goal" data-setting-item data-setting-title="Weekly business goal" data-setting-category="Business context" data-setting-description="Set the main goal workflows should prioritize this week."><span>Weekly business goal</span><textarea name="weeklyGoal" rows="3" placeholder="Example: Increase repeat orders without increasing discounts"></textarea></label>
                            </div>
                        </article>

                        <article class="settings-card" id="settings-workflow-controls" data-setting-section="Workflow controls">
                            <div class="panel-heading">
                                <div><span class="section-label">Automation</span><h3>Workflow controls</h3></div>
                                <span class="settings-section-icon"><i class="fa-solid fa-sliders" aria-hidden="true"></i></span>
                            </div>
                            <p class="settings-description">Control how much autonomy OrexisAI has when completing work.</p>
                            <div class="preference-list">
                                <label class="toggle-row" id="setting-review" data-setting-item data-setting-title="Review before publishing" data-setting-category="Workflow controls" data-setting-description="Keep generated marketing work in draft until you approve it."><span><strong>Require review before publishing</strong><small>Keep generated marketing work in draft until approved.</small></span><input type="checkbox" name="requireReview" checked><span class="toggle-control"></span></label>
                                <label class="toggle-row" id="setting-routing" data-setting-item data-setting-title="Model routing details" data-setting-category="Workflow controls" data-setting-description="Show which systems handled every workflow step."><span><strong>Show model routing details</strong><small>Display which systems handled each workflow step.</small></span><input type="checkbox" name="showRouting" checked><span class="toggle-control"></span></label>
                                <label class="toggle-row" id="setting-auto-run" data-setting-item data-setting-title="Automatic recurring workflows" data-setting-category="Workflow controls" data-setting-description="Allow approved recurring workflows to run on schedule."><span><strong>Allow scheduled auto-run</strong><small>Run approved recurring outcomes without another click.</small></span><input type="checkbox" name="allowAutoRun"><span class="toggle-control"></span></label>
                                <label class="toggle-row" id="setting-cost-guard" data-setting-item data-setting-title="Cost guardrails" data-setting-category="Workflow controls" data-setting-description="Pause workflows that may exceed your chosen usage threshold."><span><strong>Enable cost guardrails</strong><small>Pause unusually expensive workflows before they continue.</small></span><input type="checkbox" name="costGuardrails" checked><span class="toggle-control"></span></label>
                            </div>
                        </article>

                        <article class="settings-card" id="settings-notifications" data-setting-section="Notifications">
                            <div class="panel-heading">
                                <div><span class="section-label">Updates</span><h3>Notifications</h3></div>
                                <span class="settings-section-icon"><i class="fa-solid fa-bell" aria-hidden="true"></i></span>
                            </div>
                            <p class="settings-description">Choose which workflow and account updates should reach you.</p>
                            <div class="preference-list">
                                <label class="toggle-row" id="setting-email-summaries" data-setting-item data-setting-title="Email completion summaries" data-setting-category="Notifications" data-setting-description="Receive a short email summary when an outcome finishes."><span><strong>Email completion summaries</strong><small>Receive a short summary when an outcome finishes.</small></span><input type="checkbox" name="emailSummaries"><span class="toggle-control"></span></label>
                                <label class="toggle-row" id="setting-browser-alerts" data-setting-item data-setting-title="Browser notifications" data-setting-category="Notifications" data-setting-description="Show browser alerts for completed workflows and actions needing review."><span><strong>Browser notifications</strong><small>See completion and approval alerts while OrexisAI is open.</small></span><input type="checkbox" name="browserNotifications"><span class="toggle-control"></span></label>
                                <label class="toggle-row" id="setting-weekly-digest" data-setting-item data-setting-title="Weekly performance digest" data-setting-category="Notifications" data-setting-description="Receive a weekly summary of outcomes, time saved, and business signals."><span><strong>Weekly performance digest</strong><small>Get outcomes, time saved, and key business signals in one summary.</small></span><input type="checkbox" name="weeklyDigest" checked><span class="toggle-control"></span></label>
                                <label class="toggle-row" id="setting-failure-alerts" data-setting-item data-setting-title="Workflow failure alerts" data-setting-category="Notifications" data-setting-description="Always alert when a workflow fails or needs more information."><span><strong>Workflow failure alerts</strong><small>Always notify you when a workflow needs attention.</small></span><input type="checkbox" name="failureAlerts" checked><span class="toggle-control"></span></label>
                            </div>
                        </article>

                        <article class="settings-card" id="settings-privacy" data-setting-section="Privacy and data">
                            <div class="panel-heading">
                                <div><span class="section-label">Control</span><h3>Privacy & data</h3></div>
                                <span class="settings-section-icon"><i class="fa-solid fa-shield-halved" aria-hidden="true"></i></span>
                            </div>
                            <p class="settings-description">Choose what the dashboard remembers and uses for recommendations.</p>
                            <div class="preference-list">
                                <label class="toggle-row" id="setting-history" data-setting-item data-setting-title="Save workflow history" data-setting-category="Privacy and data" data-setting-description="Keep completed workflow history available in this browser."><span><strong>Save workflow history</strong><small>Keep completed outcomes available for future reference.</small></span><input type="checkbox" name="saveHistory" checked><span class="toggle-control"></span></label>
                                <label class="toggle-row" id="setting-personalization" data-setting-item data-setting-title="Personalized recommendations" data-setting-category="Privacy and data" data-setting-description="Use recent activity to rank useful workflows and suggestions."><span><strong>Personalized recommendations</strong><small>Use recent activity to prioritize useful outcomes.</small></span><input type="checkbox" name="personalizedRecommendations" checked><span class="toggle-control"></span></label>
                                <label class="toggle-row" id="setting-analytics-sharing" data-setting-item data-setting-title="Anonymous product analytics" data-setting-category="Privacy and data" data-setting-description="Share anonymous usage events to help improve the dashboard."><span><strong>Anonymous product analytics</strong><small>Share non-identifying usage events to improve OrexisAI.</small></span><input type="checkbox" name="anonymousAnalytics"><span class="toggle-control"></span></label>
                            </div>
                            <button class="danger-outline-btn" id="clearLocalDataButton" type="button"><i class="fa-solid fa-trash-can" aria-hidden="true"></i> Clear local preferences</button>
                        </article>

                        <article class="settings-card integrations-card settings-card-wide" id="settings-connections" data-setting-section="Connections">
                            <div class="panel-heading">
                                <div><span class="section-label">Connections</span><h3>Workflow data sources</h3></div>
                                <span class="settings-section-icon"><i class="fa-solid fa-plug" aria-hidden="true"></i></span>
                            </div>
                            <p class="settings-description">Connect the systems OrexisAI should use when completing work.</p>
                            <div class="integration-list">
                                ${renderIntegration('sales', 'fa-cash-register', 'Sales data', 'Use order history for campaigns, forecasts, and reports.')}
                                ${renderIntegration('social', 'fa-share-nodes', 'Social channels', 'Prepare and publish approved marketing content.')}
                                ${renderIntegration('crm', 'fa-address-book', 'Customer records', 'Power follow-ups, lead scoring, and retention workflows.')}
                            </div>
                        </article>
                    </div>

                    <div class="settings-save-bar">
                        <div>
                            <strong>Dashboard preferences</strong>
                            <span id="settingsStatus" role="status" aria-live="polite">Changes are previewed instantly.</span>
                        </div>
                        <div class="settings-save-actions">
                            <button class="secondary-action" id="resetSettingsButton" type="button">Reset defaults</button>
                            <button class="primary-action" type="submit">Save all settings</button>
                        </div>
                    </div>
                </form>
            </section>
        </main>
    </div>

    <div class="modal-overlay chat-history-modal" id="recentChatsModal" aria-hidden="true">
        <div class="chat-history-window" role="dialog" aria-modal="true" aria-labelledby="recentChatsTitle" tabindex="-1">
            <button type="button" class="close-modal chat-history-close" id="closeRecentChatsModal" aria-label="Close recent chats">
                <i class="fa-solid fa-xmark" aria-hidden="true"></i>
            </button>
            <div class="chat-history-window-header">
                <span class="chat-history-window-icon"><i class="fa-solid fa-clock-rotate-left" aria-hidden="true"></i></span>
                <div>
                    <span class="section-label">AI Agent</span>
                    <h2 id="recentChatsTitle">Recent chats</h2>
                    <p>Select a saved conversation to continue where you left off.</p>
                </div>
                <span class="chat-sync-status" id="chatSyncStatus" aria-live="polite"></span>
            </div>
            <div class="chat-history-list" id="chatHistoryList" role="list" aria-label="Saved conversations">
                <div class="chat-history-loading"><i class="fa-solid fa-circle-notch fa-spin" aria-hidden="true"></i><span>Loading chats…</span></div>
            </div>
        </div>
    </div>

    <div class="modal-overlay camera-modal" id="cameraModal" aria-hidden="true">
        <div class="camera-modal-content" role="dialog" aria-modal="true" aria-labelledby="cameraModalTitle" tabindex="-1">
            <button type="button" class="close-modal camera-modal-close" id="closeCameraModal" aria-label="Close camera">
                <i class="fa-solid fa-xmark" aria-hidden="true"></i>
            </button>
            <div class="camera-modal-heading">
                <span class="camera-modal-icon"><i class="fa-solid fa-camera" aria-hidden="true"></i></span>
                <div>
                    <span class="section-label">Device camera</span>
                    <h2 id="cameraModalTitle">Capture a photo</h2>
                    <p>Review the image before it is securely uploaded to your account.</p>
                </div>
            </div>
            <div class="camera-stage" id="cameraStage">
                <video id="cameraVideo" autoplay muted playsinline hidden></video>
                <img id="cameraPreview" alt="Captured photo preview" hidden>
                <div class="camera-placeholder" id="cameraPlaceholder">
                    <i class="fa-solid fa-camera-rotate" aria-hidden="true"></i>
                    <span>Waiting for camera permission…</span>
                </div>
            </div>
            <canvas id="cameraCanvas" hidden></canvas>
            <p class="camera-status" id="cameraStatus" role="status" aria-live="polite"></p>
            <div class="camera-actions">
                <button type="button" class="secondary-action" id="cameraFallbackButton" hidden>Use camera picker</button>
                <button type="button" class="secondary-action" id="cameraRetakeButton" hidden>
                    <i class="fa-solid fa-rotate-left" aria-hidden="true"></i> Retake
                </button>
                <button type="button" class="primary-action" id="cameraCaptureButton" disabled>
                    <i class="fa-solid fa-camera" aria-hidden="true"></i> Capture
                </button>
                <button type="button" class="primary-action" id="cameraUploadButton" hidden disabled>
                    <i class="fa-solid fa-cloud-arrow-up" aria-hidden="true"></i> Upload photo
                </button>
            </div>
        </div>
    </div>

    <div class="modal-overlay" id="executionModal" aria-hidden="true">
        <div class="modal-content glass-panel" role="dialog" aria-modal="true" aria-labelledby="workflowTitle">
            <button class="close-modal" id="closeModal" aria-label="Close"><i class="fa-solid fa-xmark" aria-hidden="true"></i></button>
            <div class="modal-header">
                <div class="running-indicator"><div class="spinner"></div></div>
                <h2 id="workflowTitle">Running workflow...</h2>
            </div>
            <div class="execution-steps" id="executionSteps"></div>
            <div class="execution-result hidden" id="executionResult">
                <div class="success-icon" id="workflowResultIcon"><i class="fa-solid fa-circle-check" aria-hidden="true"></i></div>
                <h3 id="workflowResultTitle">Outcome achieved</h3>
                <p id="workflowResultDescription">Your workflow completed successfully and the finished work is ready.</p>
                <div class="workflow-result-meta" id="workflowResultMeta"></div>
                <div class="workflow-result-body" id="workflowResultBody"></div>
                <div class="workflow-result-actions">
                    <button class="secondary-action" type="button" id="workflowRunAgainBtn"><i class="fa-solid fa-rotate" aria-hidden="true"></i> Run Again</button>
                    <button class="secondary-action" type="button" id="workflowPreviousRunsBtn"><i class="fa-solid fa-clock-rotate-left" aria-hidden="true"></i> Previous Runs</button>
                    <button class="view-result-btn" id="closeResultBtn">View workspace</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal-overlay upgrade-modal" id="upgradeModal" aria-hidden="true">
        <div class="upgrade-modal-content" role="dialog" aria-modal="true" aria-labelledby="upgradeTitle">
            <button class="close-modal" id="closeUpgradeModal" aria-label="Close upgrade plans">
                <i class="fa-solid fa-xmark" aria-hidden="true"></i>
            </button>
            <div class="upgrade-heading">
                <div>
                    <span class="eyebrow"><i class="fa-solid fa-sparkles" aria-hidden="true"></i> Upgrade OrexisAI</span>
                    <h2 id="upgradeTitle">Choose the plan that fits your workload</h2>
                    <p>Secure one-time checkout for 30 days of access. No automatic renewal is created.</p>
                </div>
                <div class="current-plan-summary">
                    <span>Current plan</span>
                    <strong data-current-plan-name>${escapeHtml(currentPlan.name)}</strong>
                    <small data-current-plan-expiry>${expiryText ? `Active until ${escapeHtml(expiryText)}` : 'No expiry'}</small>
                </div>
            </div>

            <div class="payment-message" id="paymentMessage" role="status" aria-live="polite"></div>
            <div class="plans-grid">
                ${plans.map((plan) => renderPlanCard(plan, currentPlan.id, paymentConfiguration)).join('')}
            </div>
            <p class="payment-disclaimer">
                Razorpay charges the INR amount shown. PayPal charges the USD amount shown. Your plan activates only after server-side payment confirmation.
            </p>
        </div>
    </div>

    <script src="/hyperspeed.js" nonce="${escapeHtml(cspNonce)}" defer></script>
    <script src="/orb.js" nonce="${escapeHtml(cspNonce)}" defer></script>
    <script src="/app.js" nonce="${escapeHtml(cspNonce)}" defer></script>
</body>
</html>`;
}

function renderLoginBrandIntro() {
    return `<div class="login-brand-intro" id="loginBrandIntro" role="status" aria-label="Welcome to OrexisAI">
        <div class="login-brand-glow" aria-hidden="true"></div>
        <div class="login-brand-stage">
            <div class="outcome-brand-lockup login-brand-lockup" aria-hidden="true">
                <span class="outcome-brand-o">O</span>
                <span class="outcome-brand-word-mask">
                    <span class="outcome-brand-word">rexis<span class="outcome-brand-ai">AI</span></span>
                </span>
            </div>
            <span class="login-brand-tagline">AI workflows. Real business outcomes.</span>
        </div>
        <button class="login-brand-skip" id="loginBrandSkip" type="button" aria-label="Skip logo animation">Skip</button>
    </div>`;
}

function renderWorkflowCard({ icon, gradient, title, description, time, workflow, search }) {
    return `<article class="workflow-card searchable-item" data-search-text="${escapeHtml(search)}">
        <div class="card-icon ${escapeHtml(gradient)}"><i class="fa-solid ${escapeHtml(icon)}" aria-hidden="true"></i></div>
        <h3>${escapeHtml(title)}</h3>
        <p>${escapeHtml(description)}</p>
        <div class="card-footer">
            <span class="time"><i class="fa-regular fa-clock" aria-hidden="true"></i> ${escapeHtml(time)}</span>
            <button class="run-btn" type="button" data-workflow="${escapeHtml(workflow)}">Run Now <i class="fa-solid fa-play" aria-hidden="true"></i></button>
        </div>
    </article>`;
}

function renderBar(label, height, value) {
    return `<div class="bar-column"><span class="bar-value">${escapeHtml(value)}</span><div class="bar-track"><div class="bar-fill" style="height:${Number(height)}%"></div></div><span class="bar-label">${escapeHtml(label)}</span></div>`;
}

function renderCustomer(name, initials, signal, action, state) {
    return `<div class="customer-row" role="row">
        <span class="customer-name" role="cell"><span class="mini-avatar">${escapeHtml(initials)}</span><strong>${escapeHtml(name)}</strong></span>
        <span role="cell"><span class="customer-signal ${escapeHtml(state)}">${escapeHtml(signal)}</span></span>
        <span role="cell">${escapeHtml(action)}</span>
    </div>`;
}

function renderIntegration(id, icon, name, description) {
    return `<div class="integration-row" id="setting-integration-${escapeHtml(id)}" data-integration-row="${escapeHtml(id)}" data-setting-item data-setting-title="${escapeHtml(name)} connection" data-setting-category="Connections" data-setting-description="${escapeHtml(description)}">
        <span class="integration-icon"><i class="fa-solid ${escapeHtml(icon)}" aria-hidden="true"></i></span>
        <div><strong>${escapeHtml(name)}</strong><small>${escapeHtml(description)}</small></div>
        <button class="integration-connect-btn" type="button" data-integration="${escapeHtml(id)}">Connect</button>
    </div>`;
}

function renderPlanCard(plan, currentPlanId, paymentConfiguration) {
    const isCurrent = plan.id === currentPlanId;
    const isFree = plan.usdCents === 0;
    const usd = `$${(plan.usdCents / 100).toFixed(0)}`;
    const inr = new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        maximumFractionDigits: 0
    }).format(plan.inrPaise / 100);

    return `<article class="plan-card${plan.featured ? ' featured' : ''}${isCurrent ? ' current' : ''}" data-plan-card="${escapeHtml(plan.id)}">
        ${plan.featured ? '<span class="popular-badge">Most popular</span>' : ''}
        <div class="plan-card-head">
            <div>
                <h3>${escapeHtml(plan.name)}</h3>
                <p>${escapeHtml(plan.tagline)}</p>
            </div>
            ${isCurrent ? '<span class="current-badge">Current</span>' : ''}
        </div>
        <div class="plan-price">
            <strong>${isFree ? '$0' : usd}</strong>
            <span>${isFree ? 'forever' : 'for 30 days'}</span>
        </div>
        <div class="razorpay-price">${escapeHtml(inr)} INR${isFree ? '' : ' with Razorpay'}</div>
        <ul class="plan-features">
            ${plan.features.map((feature) => `<li><i class="fa-solid fa-check" aria-hidden="true"></i>${escapeHtml(feature)}</li>`).join('')}
        </ul>
        <div class="payment-actions">
            ${isFree
        ? `<button class="plan-disabled-btn" type="button" disabled>${isCurrent ? 'Your current plan' : 'Included by default'}</button>`
        : `<button class="razorpay-pay-btn" type="button" data-plan-id="${escapeHtml(plan.id)}"${paymentConfiguration.razorpay.isConfigured ? '' : ' disabled'}>
                    <i class="fa-solid fa-credit-card" aria-hidden="true"></i>
                    ${paymentConfiguration.razorpay.isConfigured ? 'Pay with Razorpay' : 'Razorpay not configured'}
                </button>
                <div class="paypal-button-slot" data-plan-id="${escapeHtml(plan.id)}">
                    ${paymentConfiguration.paypal.isConfigured ? '<span class="paypal-loading">Loading PayPal…</span>' : '<button class="plan-disabled-btn" type="button" disabled>PayPal not configured</button>'}
                </div>`}
        </div>
    </article>`;
}

module.exports = {
    escapeHtml,
    renderBar,
    renderCustomer,
    renderDashboardPage,
    renderIntegration,
    renderLoginBrandIntro,
    renderPlanCard,
    renderWorkflowCard
};
