'use strict';

const { DEFAULT_CHANNELS } = require('./marketing-ai');
const { validateMarketingRunInput, publicError } = require('./security');
const { sanitizePlainText } = require('./marketing-utils');

const IMAGE_CONCURRENCY = 2;
const MARKETING_IMAGE_DEFINITIONS = Object.freeze([
    Object.freeze({ key: 'weekly-social-creative', title: 'Weekly Social Creative', aspectRatio: '1:1' }),
    Object.freeze({ key: 'weekly-promotional-poster', title: 'Weekly Promotional Poster', aspectRatio: '4:5' }),
    Object.freeze({ key: 'weekly-marketing-banner', title: 'Weekly Marketing Banner', aspectRatio: '16:9' })
]);

async function executeMarketingOperatingWorkflow({
    userId,
    business,
    input,
    step,
    database,
    geminiService,
    analyticsEngine,
    marketingAiService,
    liveDataCollector,
    competitorIntelligenceService,
    reportService,
    runId,
    log
}) {
    const request = validateMarketingRunInput(input);
    const runtimeLimitations = [];
    const databaseSnapshot = await step('collect-database-data', async () => analyticsEngine.buildWorkspace({
        userId,
        businessId: business.id,
        from: request.from,
        to: request.to,
        timezone: business.timezone || 'UTC',
        defaultDays: 7,
        bypassCache: request.forceRefresh
    }));

    const validation = await step('validate-records', async () => validateWorkspace(databaseSnapshot));
    const kpis = await step('calculate-kpis', async () => databaseSnapshot.metrics);
    const comparisons = await step('compare-periods', async () => ({
        selectedPeriod: databaseSnapshot.trends.selectedPeriodComparison,
        daily: databaseSnapshot.trends.dailyComparison,
        weekly: databaseSnapshot.trends.weeklyComparison,
        monthly: databaseSnapshot.trends.monthlyComparison,
        quarterly: databaseSnapshot.trends.quarterlyComparison,
        yearOverYear: databaseSnapshot.trends.yearOverYearComparison,
        periods: databaseSnapshot.periodComparisons,
        dataPeriod: databaseSnapshot.dataPeriod,
        previousPeriod: databaseSnapshot.previousPeriod,
        yearAgoPeriod: databaseSnapshot.yearAgoPeriod
    }));
    const decliningProducts = await step('identify-declining-products', async () => databaseSnapshot.products.declining);
    const bestSellers = await step('identify-best-sellers', async () => databaseSnapshot.products.top);
    const customerSegments = await step('segment-customers', async () => databaseSnapshot.customers.segments);
    const deterministicOpportunities = await step('calculate-opportunities', async () => databaseSnapshot.opportunities);
    const stockRisks = await step('detect-stock-risks', async () => databaseSnapshot.products.stockAlerts);

    const context = await step('load-marketing-context', async () => {
        try {
            return await database.getWeeklyMarketingContext({ userId, businessId: business.id });
        } catch (error) {
            const limitation = optionalFailureMessage('Marketing context enrichment', error);
            runtimeLimitations.push(limitation);
            console.warn(`[workflow:${Number(runId)}] optional marketing context unavailable:`, error);
            await log('warning', limitation, { code: error.code || null, optional: true });
            return {
                business,
                competitors: [],
                reviews: [],
                retrievedAt: new Date().toISOString()
            };
        }
    });
    const liveData = await step('collect-competitor-data', async () => {
        let collected;
        try {
            collected = await liveDataCollector.collect({
                business: context.business,
                competitors: request.competitorScan ? context.competitors : [],
                databaseReviews: context.reviews,
                period: {
                    current: databaseSnapshot.dataPeriod,
                    previous: databaseSnapshot.previousPeriod
                },
                onLog: (level, message) => { void log(level, message, { sourceCollection: true }); }
            });
        } catch (error) {
            const limitation = optionalFailureMessage('Live marketing source collection', error);
            runtimeLimitations.push(limitation);
            console.warn(`[workflow:${Number(runId)}] optional live source collection failed:`, error);
            await log('warning', limitation, { code: error.code || null, optional: true });
            collected = {
                snapshots: [],
                available: {},
                unavailable: [{ sourceType: 'live-marketing-sources', reason: limitation }],
                retrievedAt: new Date().toISOString()
            };
        }

        try {
            await database.saveWorkflowSourceSnapshots({ runId, snapshots: collected.snapshots });
        } catch (error) {
            const limitation = optionalFailureMessage('Live-source audit storage', error);
            runtimeLimitations.push(limitation);
            console.warn(`[workflow:${Number(runId)}] optional source snapshot persistence failed:`, error);
            await log('warning', limitation, { code: error.code || null, optional: true });
        }

        let persistedCompetitorSnapshots = 0;
        try {
            const savedCompetitors = await competitorIntelligenceService.persistLiveFindings({
                userId,
                businessId: business.id,
                liveData: collected
            });
            persistedCompetitorSnapshots = savedCompetitors.length;
        } catch (error) {
            const limitation = optionalFailureMessage('Competitor snapshot persistence', error);
            runtimeLimitations.push(limitation);
            console.warn(`[workflow:${Number(runId)}] optional competitor snapshot persistence failed:`, error);
            await log('warning', limitation, { code: error.code || null, optional: true });
        }
        return { ...collected, persistedCompetitorSnapshots };
    });

    const marketTrends = await step('collect-market-trends', async () => extractVerifiedMarketTrends(liveData));
    const requestedChannels = request.channels.length ? request.channels : DEFAULT_CHANNELS;
    const aiExecution = await step('generate-ai-reasoning', async () => marketingAiService.reason({
        workspace: databaseSnapshot,
        liveData,
        objective: request.objective,
        channels: requestedChannels
    }));
    const { auditPrompt, ...ai } = aiExecution;
    await step('save-ai-audit', async () => {
        try {
            const savedAudit = await database.saveWorkflowAiExecution({
                runId,
                model: ai.model,
                promptText: auditPrompt,
                response: ai,
                contextHash: ai.contextHash
            });
            return { persisted: true, id: Number(savedAudit?.id || 0) || null };
        } catch (error) {
            const limitation = optionalFailureMessage('AI audit storage', error);
            runtimeLimitations.push(limitation);
            console.warn(`[workflow:${Number(runId)}] optional AI audit persistence failed:`, error);
            await log('warning', limitation, { code: error.code || null, optional: true });
            return { persisted: false };
        }
    });

    const campaignIdeas = await step('generate-campaign-ideas', async () => ai.campaignPlan.map((campaign) => ({
        channel: campaign.channel,
        title: campaign.title,
        rationale: campaign.rationale,
        verifiedFacts: campaign.verifiedFacts
    })));
    const socialPosts = await step('generate-social-posts', async () => selectCampaigns(ai.campaignPlan, ['instagram', 'facebook']));
    const emailCampaign = await step('generate-email-campaign', async () => selectCampaigns(ai.campaignPlan, ['email']));
    const whatsappCampaign = await step('generate-whatsapp-campaign', async () => selectCampaigns(ai.campaignPlan, ['whatsapp']));
    const instagramCaptions = await step('generate-instagram-captions', async () => selectCampaigns(ai.campaignPlan, ['instagram']));
    const facebookAds = await step('generate-facebook-ads', async () => selectCampaigns(ai.campaignPlan, ['facebook']));
    const googleAds = await step('generate-google-ads', async () => selectCampaigns(ai.campaignPlan, ['google-ads']));
    const seoPlan = await step('generate-seo-plan', async () => ({
        keywords: ai.seoPlan.keywords,
        blogIdeas: ai.seoPlan.blogIdeas
    }));
    const landingPageImprovements = await step('improve-landing-page', async () => ai.seoPlan.landingPageImprovements);
    const discountRecommendations = await step('recommend-discounts', async () => ai.productStrategy.map((item) => ({
        productName: item.productName,
        recommendation: item.discountRecommendation,
        inventoryConstraint: item.inventoryConstraint,
        evidence: item.evidence
    })).filter((item) => item.recommendation));
    const pricingRecommendations = await step('recommend-pricing', async () => ai.productStrategy.map((item) => ({
        productName: item.productName,
        recommendation: item.pricingRecommendation,
        evidence: item.evidence
    })).filter((item) => item.recommendation));

    const generatedImages = await step('generate-creative-images', async () => {
        if (!request.generateImages) {
            await log('info', 'Campaign creative generation was disabled for this run.', { imageGeneration: 'disabled' });
            return [];
        }
        return generateCampaignCreatives({
            geminiService,
            database,
            runId,
            business: context.business,
            workspace: databaseSnapshot,
            ai,
            log
        });
    });

    const growthPlan = await step('assemble-growth-plan', async () => {
        let savedCampaigns = [];
        let contentArtifact = null;
        let reports = [];

        try {
            savedCampaigns = await database.saveMarketingCampaignAssets({
                userId,
                businessId: business.id,
                runId,
                campaigns: ai.campaignPlan
            });
        } catch (error) {
            const limitation = optionalFailureMessage('Campaign draft storage', error);
            runtimeLimitations.push(limitation);
            console.warn(`[workflow:${Number(runId)}] optional campaign persistence failed:`, error);
            await log('warning', limitation, { code: error.code || null, optional: true });
        }

        try {
            contentArtifact = await database.saveWorkflowArtifact({
                runId,
                sectionKey: 'marketing-operating-plan',
                artifactType: 'json',
                title: 'Marketing Operating Plan',
                filename: `marketing-operating-plan-${new Date().toISOString().slice(0, 10)}.json`,
                mimeType: 'application/json',
                contentText: JSON.stringify({ analytics: databaseSnapshot, ai }, null, 2),
                metadata: { contextHash: ai.contextHash, model: ai.model, campaignCount: savedCampaigns.length }
            });
        } catch (error) {
            const limitation = optionalFailureMessage('Marketing-plan artifact storage', error);
            runtimeLimitations.push(limitation);
            console.warn(`[workflow:${Number(runId)}] optional operating-plan artifact persistence failed:`, error);
            await log('warning', limitation, { code: error.code || null, optional: true });
        }

        try {
            reports = await createReports({
                reportService,
                database,
                runId,
                business: context.business,
                databaseSnapshot,
                ai,
                liveData,
                images: generatedImages.filter((item) => item.status === 'generated')
            });
        } catch (error) {
            const limitation = optionalFailureMessage('Report generation or storage', error);
            runtimeLimitations.push(limitation);
            console.warn(`[workflow:${Number(runId)}] optional report generation failed:`, error);
            await log('warning', limitation, { code: error.code || null, optional: true });
        }

        return {
            savedCampaigns: savedCampaigns.map(serializeCampaignAsset),
            contentArtifact: contentArtifact ? serializeArtifact(contentArtifact) : null,
            reports
        };
    });

    const allArtifacts = await step('load-artifacts', async () => {
        try {
            return await database.listWorkflowArtifacts({ userId, runId });
        } catch (error) {
            const limitation = optionalFailureMessage('Workflow artifact listing', error);
            runtimeLimitations.push(limitation);
            console.warn(`[workflow:${Number(runId)}] optional artifact listing failed:`, error);
            await log('warning', limitation, { code: error.code || null, optional: true });
            return [];
        }
    });
    const imageLimitations = generatedImages
        .filter((item) => item.status === 'failed')
        .map((item) => `${item.title}: ${item.error || 'Image generation failed.'}`);
    const limitations = [...new Set([
        ...(databaseSnapshot.limitations || []),
        ...(liveData.unavailable || []).map((item) => `${item.sourceType}: ${item.reason}`),
        ...(ai.dataLimitations || []),
        ...runtimeLimitations,
        ...imageLimitations
    ].filter(Boolean))];

    return {
        period: { from: new Date(databaseSnapshot.dataPeriod.from), to: new Date(databaseSnapshot.dataPeriod.to) },
        dataRetrievedAt: databaseSnapshot.generatedAt,
        recordsAnalyzed: databaseSnapshot.recordsAnalyzed,
        output: {
            workflow: 'weekly-marketing',
            workflowVersion: 3,
            trustworthy: true,
            partial: limitations.length > 0,
            business: databaseSnapshot.business,
            dataPeriod: databaseSnapshot.dataPeriod,
            previousPeriod: databaseSnapshot.previousPeriod,
            yearAgoPeriod: databaseSnapshot.yearAgoPeriod,
            recordsAnalyzed: databaseSnapshot.recordsAnalyzed,
            validation,
            analytics: databaseSnapshot,
            internalPerformance: {
                factualResults: summarizeFactualResults(databaseSnapshot),
                calculatedMetrics: kpis
            },
            comparisons,
            decliningProducts,
            bestSellers,
            customerSegments,
            deterministicOpportunities,
            stockRisks,
            marketTrends,
            aiReasoning: {
                executiveSummary: ai.executiveSummary,
                findings: ai.findings,
                opportunities: ai.opportunities,
                customerStrategy: ai.customerStrategy,
                productStrategy: ai.productStrategy,
                nextActions: ai.nextActions,
                model: ai.model,
                contextHash: ai.contextHash,
                repaired: Boolean(ai.repaired),
                fallbackUsed: Boolean(ai.fallbackUsed)
            },
            campaignIdeas,
            campaigns: {
                socialPosts,
                emailCampaign,
                whatsappCampaign,
                instagramCaptions,
                facebookAds,
                googleAds,
                all: ai.campaignPlan
            },
            seoPlan,
            landingPageImprovements,
            discountRecommendations,
            pricingRecommendations,
            generatedImages: generatedImages.map(({ binary, ...item }) => item),
            reports: growthPlan.reports,
            artifacts: allArtifacts.map(serializeArtifact),
            growthPlan,
            sourceSummary: liveData.snapshots.map(serializeSource),
            dataLimitations: limitations
        }
    };
}


function optionalFailureMessage(label, error) {
    const code = String(error?.code || '').trim();
    const publicMessage = String(error?.publicMessage || '').trim();
    const suffix = publicMessage && !/^the workflow/i.test(publicMessage)
        ? publicMessage
        : 'The optional subsystem was unavailable, so the rest of Weekly Marketing continued without it.';
    return `${label}${code ? ` (${code})` : ''}: ${suffix}`;
}

function validateWorkspace(workspace) {
    if (!workspace?.business?.id) throw publicError('MARKETING_BUSINESS_MISSING', 'The selected business could not be loaded.', 404);
    const freshness = workspace.freshness || {};
    const records = Number(workspace.recordsAnalyzed || 0);
    if (records < 1) throw publicError('MARKETING_DATA_REQUIRED', 'Connect or import real business records before running weekly marketing.', 422);
    return {
        valid: true,
        recordsAnalyzed: records,
        orderRecords: Number(freshness.orderRecords || 0),
        customerRecords: Number(freshness.customerRecords || 0),
        productRecords: Number(freshness.productRecords || 0),
        campaignRecords: Number(freshness.campaignRecords || 0),
        trafficRecords: Number(freshness.trafficRecords || 0),
        cartRecords: Number(freshness.cartRecords || 0),
        limitations: workspace.limitations || []
    };
}

function extractVerifiedMarketTrends(liveData) {
    const available = liveData?.available || {};
    return {
        keywords: available['trending-keywords'] || null,
        googleTrends: available['google-trends'] || null,
        industryNews: available['industry-news'] || null,
        localEvents: available['local-events'] || null,
        seasonalEvents: available['seasonal-events'] || null,
        weather: available.weather || null,
        socialTrends: available['social-media-trends'] || null,
        sourcesAvailable: Object.keys(available)
    };
}

function selectCampaigns(campaigns, channels) {
    const allowed = new Set(channels);
    return campaigns.filter((campaign) => allowed.has(campaign.channel));
}

async function createReports({ reportService, database, runId, business, databaseSnapshot, ai, liveData, images = [] }) {
    const report = {
        executiveSummary: ai.executiveSummary,
        verifiedAnalytics: databaseSnapshot,
        findings: ai.findings,
        opportunities: ai.opportunities,
        customerStrategy: ai.customerStrategy,
        productStrategy: ai.productStrategy,
        campaigns: ai.campaignPlan,
        seoPlan: ai.seoPlan,
        nextActions: ai.nextActions,
        dataLimitations: [...(databaseSnapshot.limitations || []), ...(liveData.unavailable || []).map((item) => `${item.sourceType}: ${item.reason}`)]
    };
    const generated = await reportService.generate({
        business,
        report,
        images,
        generatedAt: new Date().toISOString()
    });
    const saved = [];
    for (const file of generated) saved.push(serializeArtifact(await database.saveWorkflowArtifact({ runId, ...file })));
    return saved;
}


async function generateCampaignCreatives({ geminiService, database, runId, business, workspace, ai, log }) {
    const configuration = typeof geminiService?.getPublicConfiguration === 'function'
        ? geminiService.getPublicConfiguration()
        : {};
    if (!configuration.imageGenerationConfigured || typeof geminiService?.generateImage !== 'function') {
        await log('info', 'AI image generation is not configured; text campaigns and reports will still be produced.', { imageGeneration: 'skipped' });
        return [];
    }

    const definitions = buildCreativeDefinitions({ business, workspace, ai });
    const results = new Array(definitions.length);
    let nextIndex = 0;
    async function worker() {
        while (nextIndex < definitions.length) {
            const index = nextIndex++;
            const definition = definitions[index];
            try {
                const generated = await geminiService.generateImage({
                    prompt: definition.prompt,
                    aspectRatio: definition.aspectRatio,
                    imageSize: '1K'
                });
                const filename = `${safeSlug(business?.name || 'business')}-${definition.key}-${new Date().toISOString().slice(0, 10)}.png`;
                const artifact = await database.saveWorkflowArtifact({
                    runId,
                    sectionKey: definition.key,
                    artifactType: 'image',
                    title: definition.title,
                    filename,
                    mimeType: generated.mimeType || 'image/png',
                    binary: generated.binary,
                    metadata: {
                        model: generated.model || configuration.imageModel || null,
                        aspectRatio: definition.aspectRatio,
                        prompt: definition.prompt,
                        weeklyMarketingV3: true
                    }
                });
                await log('info', `Generated ${definition.title}.`, { artifactId: Number(artifact.id) });
                results[index] = {
                    ...serializeArtifact(artifact),
                    binary: generated.binary,
                    status: 'generated'
                };
            } catch (error) {
                const message = error?.publicMessage || error?.message || 'Image generation failed.';
                await log('warning', `${definition.title} could not be generated: ${message}`, { code: error?.code || null });
                results[index] = {
                    sectionKey: definition.key,
                    title: definition.title,
                    status: 'failed',
                    error: message
                };
            }
        }
    }
    await Promise.all(Array.from({ length: Math.min(IMAGE_CONCURRENCY, definitions.length) }, () => worker()));
    return results.filter(Boolean);
}

function buildCreativeDefinitions({ business, workspace, ai }) {
    const businessName = sanitizePlainText(business?.name || workspace?.business?.name || 'the business', 160);
    const industry = sanitizePlainText(business?.industry || workspace?.business?.industry || 'business', 160);
    const brandVoice = sanitizePlainText(business?.brand_voice || business?.brandVoice || 'professional and clear', 220);
    const topProducts = (workspace?.products?.top || []).slice(0, 3).map((item) => sanitizePlainText(item.productName, 160)).filter(Boolean);
    const preferredCampaign = (ai?.campaignPlan || []).find((campaign) => ['instagram', 'facebook'].includes(campaign.channel))
        || (ai?.campaignPlan || [])[0]
        || null;
    const campaignTitle = sanitizePlainText(preferredCampaign?.title || ai?.executiveSummary || 'Weekly marketing campaign', 240);
    const productContext = topProducts.length ? `Feature these verified products where visually useful: ${topProducts.join(', ')}.` : 'Do not invent product names or product claims.';
    const base = [
        `Create an original marketing visual for ${businessName}.`,
        `Industry: ${industry}.`,
        `Brand voice: ${brandVoice}.`,
        `Campaign direction: ${campaignTitle}.`,
        productContext,
        'Do not invent prices, discounts, ratings, guarantees, awards, logos, testimonials, or performance claims.',
        'Use a clean commercially usable composition, original imagery, strong hierarchy, and no watermarks.',
        'Avoid dense body copy; prioritize visual design and leave clear space for editable campaign text.'
    ].join(' ');
    return MARKETING_IMAGE_DEFINITIONS.map((definition) => ({
        ...definition,
        prompt: `${base} Format: ${definition.title}, aspect ratio ${definition.aspectRatio}.`
    }));
}

function safeSlug(value) {
    return String(value || 'business').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 80) || 'business';
}

function summarizeFactualResults(workspace) {
    return {
        currency: workspace.business.currency,
        totalRevenueMinor: workspace.metrics.revenue.value,
        totalOrders: workspace.metrics.orders.value,
        averageOrderValueMinor: workspace.metrics.averageOrderValue.value,
        uniqueCustomers: workspace.metrics.newCustomers.value + workspace.metrics.returningCustomers.value,
        topProducts: workspace.products.top,
        dailyTrend: workspace.trends.daily,
        campaign: workspace.campaigns.totals,
        campaignDataAvailable: workspace.campaigns.rows.length > 0,
        periodDays: Math.max(1, workspace.trends.daily.length)
    };
}

function serializeSource(snapshot) {
    return {
        sourceType: snapshot.sourceType,
        provider: snapshot.provider,
        status: snapshot.status,
        sourceUrl: snapshot.sourceUrl || null,
        error: snapshot.errorMessage || null,
        retrievedAt: snapshot.retrievedAt
    };
}

function serializeCampaignAsset(row) {
    return {
        id: Number(row.id),
        runId: Number(row.run_id),
        channel: row.channel,
        title: row.title,
        content: row.content,
        rationale: row.rationale || null,
        verifiedFacts: row.verified_facts || [],
        status: row.status,
        createdAt: row.created_at
    };
}

function serializeArtifact(row) {
    return {
        id: Number(row.id),
        runId: Number(row.run_id),
        sectionKey: row.section_key,
        artifactType: row.artifact_type,
        title: row.title,
        filename: row.filename || null,
        mimeType: row.mime_type,
        sizeBytes: Number(row.size_bytes || 0),
        sha256: row.sha256,
        metadata: row.metadata || {},
        createdAt: row.created_at,
        downloadUrl: `/api/workflow-artifacts/${Number(row.id)}/download`
    };
}

module.exports = {
    executeMarketingOperatingWorkflow,
    extractVerifiedMarketTrends,
    summarizeFactualResults,
    validateWorkspace
};
