'use strict';

const { getWorkflow, listWorkflows } = require('./registry');
const { createLiveMarketingDataCollector } = require('./live-marketing-data');
const { createMarketingReportService } = require('./report-service');
const { regenerateWeeklyMarketingSection, serializeArtifact } = require('./weekly-marketing');
const { createMarketingAnalyticsEngine } = require('./analytics-engine');
const { createMarketingAiService } = require('./marketing-ai');
const { createCompetitorIntelligenceService, computeNextRun } = require('./marketing-services');
const { executeMarketingOperatingWorkflow } = require('./marketing-orchestrator');
const { validateSchedulePayload } = require('./security');
const { createEnterpriseAnalyticsService } = require('./enterprise-analytics');
const { createAnalyticsDemoPayload, DEMO_DATASET_VERSION } = require('./analytics-demo-data');
const { createInventoryDemoPayload, INVENTORY_DEMO_VERSION } = require('./inventory-demo-data');
const { createAnalyticsExport, buildAnalyticsEmail } = require('./analytics-export');
const { validateBusinessImportPayload } = require('../business-data');
const {
    calculateInventoryForecast,
    growthPercentage,
    resolveComparablePeriod,
    safeDivide
} = require('./calculations');

const MAX_AI_FACT_BYTES = 96 * 1024;
const MAX_REVIEW_BATCH = 20;

function createWorkflowService({ database, geminiService, emailService = null, env = process.env, fetchImpl = globalThis.fetch }) {
    if (!database) throw new TypeError('A database service is required.');
    if (!geminiService) throw new TypeError('An AI service is required.');

    const reviewResponseConnector = createReviewResponseConnector({ env, fetchImpl });
    const liveDataCollector = createLiveMarketingDataCollector({ env, fetchImpl });
    const reportService = createMarketingReportService();
    const analyticsEngine = createMarketingAnalyticsEngine({
        database,
        cacheTtlSeconds: parseBoundedInteger(env.MARKETING_DASHBOARD_CACHE_SECONDS, 30, 5, 300)
    });
    const marketingAiService = createMarketingAiService({ geminiService });
    const competitorIntelligenceService = createCompetitorIntelligenceService({ database });
    const enterpriseAnalyticsService = createEnterpriseAnalyticsService({ database, analyticsEngine });

    return {
        listDefinitions() {
            return listWorkflows().map(serializeWorkflowDefinition);
        },

        async execute({ userId, businessId = null, slug, input = {}, onEvent = () => {} }) {
            const workflow = getWorkflow(slug);
            if (!workflow) throw createWorkflowError('WORKFLOW_NOT_FOUND', 'That workflow does not exist.', 404);

            const business = businessId === null || businessId === undefined
                ? await database.getOrCreateBusinessForUser(userId)
                : await database.getBusinessForUser({ userId, businessId });
            const staleAfterSeconds = parseBoundedInteger(env.WORKFLOW_STALE_RUN_SECONDS, 300, 60, 3600);
            const configuredMaxRunSeconds = parseBoundedInteger(env.WORKFLOW_MAX_RUN_SECONDS, 900, 300, 7200);
            const maxRunSeconds = Math.max(configuredMaxRunSeconds, staleAfterSeconds + 60);
            const run = await database.createWorkflowRun({
                userId,
                businessId: business.id,
                workflow,
                input,
                staleAfterSeconds,
                maxRunSeconds
            });
            emit(onEvent, 'run', { run: serializeRun(run) });
            const startedAt = Date.now();
            const deadlineAt = startedAt + maxRunSeconds * 1000;
            let heartbeat = null;
            let execution;
            try {
                const running = await database.updateWorkflowRun({
                    runId: run.id,
                    status: 'running',
                    businessId: business.id
                });
                if (!running) {
                    throw createWorkflowError(
                        'WORKFLOW_LEASE_LOST',
                        'The workflow execution lease could not be activated. Run the workflow again.',
                        409
                    );
                }
                emit(onEvent, 'status', { status: 'running', runId: Number(run.id) });

                heartbeat = startWorkflowHeartbeat({
                    database,
                    runId: run.id,
                    businessId: business.id,
                    staleAfterSeconds
                });
                const { step, log } = createStepExecutor({
                    database, onEvent, runId: run.id, workflow, startedAt, deadlineAt
                });
                execution = await withWorkflowExecutionTimeout(() => executeBySlug({
                    workflow,
                    userId,
                    business,
                    input,
                    step,
                    database,
                    geminiService,
                    liveDataCollector,
                    reportService,
                    analyticsEngine,
                    marketingAiService,
                    competitorIntelligenceService,
                    runId: run.id,
                    log
                }), maxRunSeconds);
                const durationMs = Date.now() - startedAt;
                const completed = await step('save-result', async () => ({ persisted: true }));
                void completed;
                const saved = await database.updateWorkflowRun({
                    runId: run.id,
                    status: 'completed',
                    output: execution.output,
                    businessId: business.id,
                    periodStart: execution.period?.from || null,
                    periodEnd: execution.period?.to || null,
                    dataRetrievedAt: execution.dataRetrievedAt || new Date().toISOString(),
                    recordsAnalyzed: execution.recordsAnalyzed || 0,
                    durationMs,
                    progressPercentage: 100,
                    currentStep: 'completed',
                    estimatedCompletionAt: new Date().toISOString()
                });
                if (!saved) {
                    throw createWorkflowError(
                        'WORKFLOW_LEASE_LOST',
                        'The workflow execution lease expired before the result could be saved. Run it again.',
                        409
                    );
                }
                const result = { ...serializeRun(saved), steps: undefined };
                emit(onEvent, 'completed', { run: result, output: execution.output });
                return { run: result, output: execution.output };
            } catch (error) {
                const durationMs = Date.now() - startedAt;
                const publicMessage = error.publicMessage || 'The workflow could not produce a trustworthy result.';
                await database.finalizeActiveWorkflowSteps?.({
                    runId: run.id,
                    errorMessage: publicMessage
                }).catch(() => {});
                await database.updateWorkflowRun({
                    runId: run.id,
                    status: 'failed',
                    output: execution?.output || null,
                    errorMessage: publicMessage,
                    businessId: business.id,
                    periodStart: execution?.period?.from || null,
                    periodEnd: execution?.period?.to || null,
                    dataRetrievedAt: execution?.dataRetrievedAt || new Date().toISOString(),
                    recordsAnalyzed: execution?.recordsAnalyzed || 0,
                    durationMs,
                    currentStep: 'failed',
                    estimatedCompletionAt: null
                }).catch(() => {});
                emit(onEvent, 'failed', {
                    code: error.code || 'WORKFLOW_FAILED',
                    error: publicMessage,
                    runId: Number(run.id)
                });
                throw error;
            } finally {
                if (heartbeat) clearInterval(heartbeat);
            }
        },

        async getOverview({ userId, from, to }) {
            const business = await database.getOrCreateBusinessForUser(userId);
            const period = resolveComparablePeriod({ from, to });
            const data = await database.getBusinessOverview({
                userId,
                businessId: business.id,
                current: period.current,
                previous: period.previous
            });
            return buildOverview(data, period);
        },

        async getMarketingWorkspace({ userId, from = '', to = '', bypassCache = false }) {
            const business = await database.getOrCreateBusinessForUser(userId);
            return analyticsEngine.buildWorkspace({ userId, businessId: business.id, from, to, timezone: business.timezone || 'UTC', bypassCache });
        },

        async getEnterpriseAnalytics({ userId, from = '', to = '', filters = {}, bypassCache = false }) {
            return enterpriseAnalyticsService.buildDashboard({ userId, from, to, filters, bypassCache });
        },

        async getInventoryDataSummary({ userId }) {
            const business = await database.getOrCreateBusinessForUser(userId);
            const summary = await database.getInventoryDataSummary({ userId, businessId: business.id });
            return { business: serializeBusiness(business), ...summary };
        },

        async loadInventoryDemoData({ userId }) {
            const business = await database.getOrCreateBusinessForUser(userId);
            const state = await database.getInventoryDatasetState({ userId, businessId: business.id });
            if (Number(state.real_order_records || 0) > 0) {
                throw createWorkflowError('INVENTORY_DEMO_REAL_DATA_PRESENT', 'Demo inventory data cannot be loaded because this business already has real order records.', 409);
            }
            if (Number(state.demo_order_records || 0) > 0) {
                return { loaded: false, alreadyLoaded: true, datasetVersion: INVENTORY_DEMO_VERSION };
            }
            const payload = validateBusinessImportPayload(createInventoryDemoPayload({
                businessId: business.id,
                currency: business.currency || 'USD',
                timezone: business.timezone || 'UTC',
                countryCode: business.country_code || 'IN'
            }));
            const imported = await database.importBusinessData({ userId, businessId: business.id, payload });
            return { loaded: true, alreadyLoaded: false, datasetVersion: INVENTORY_DEMO_VERSION, import: imported };
        },

        async removeInventoryDemoData({ userId }) {
            const business = await database.getOrCreateBusinessForUser(userId);
            return database.deleteInventoryDemoData({ userId, businessId: business.id });
        },

        async exportEnterpriseAnalytics({ userId, from = '', to = '', filters = {}, format }) {
            const dashboard = await enterpriseAnalyticsService.buildDashboard({ userId, from, to, filters, bypassCache: true });
            return createAnalyticsExport({ format, dashboard });
        },

        async emailEnterpriseAnalytics({ userId, email, from = '', to = '', filters = {} }) {
            if (!emailService?.isConfigured || typeof emailService.sendAnalyticsReport !== 'function') {
                throw createWorkflowError('ANALYTICS_EMAIL_NOT_CONFIGURED', 'Report email is not configured. Set EMAIL_PROVIDER, RESEND_API_KEY, and EMAIL_FROM.', 503);
            }
            const dashboard = await enterpriseAnalyticsService.buildDashboard({ userId, from, to, filters, bypassCache: true });
            const report = buildAnalyticsEmail(dashboard);
            const sent = await emailService.sendAnalyticsReport({ to: email, ...report });
            return { sent: true, id: sent.id || '', generatedAt: dashboard.generatedAt };
        },

        async loadAnalyticsDemoData({ userId }) {
            const business = await database.getOrCreateBusinessForUser(userId);
            const state = await database.getAnalyticsDatasetState({ userId, businessId: business.id });
            if (Number(state.real_order_records || 0) > 0) {
                throw createWorkflowError('ANALYTICS_DEMO_REAL_DATA_PRESENT', 'Demo data cannot be loaded because this business already has real order records.', 409);
            }
            if (Number(state.demo_order_records || 0) > 0) {
                return { loaded: false, alreadyLoaded: true, datasetVersion: DEMO_DATASET_VERSION };
            }
            const payload = validateBusinessImportPayload(createAnalyticsDemoPayload({
                businessId: business.id,
                currency: business.currency || 'USD',
                timezone: business.timezone || 'UTC'
            }));
            const imported = await database.importBusinessData({ userId, businessId: business.id, payload });
            return { loaded: true, alreadyLoaded: false, datasetVersion: DEMO_DATASET_VERSION, import: imported };
        },

        async removeAnalyticsDemoData({ userId }) {
            const business = await database.getOrCreateBusinessForUser(userId);
            return database.deleteAnalyticsDemoData({ userId, businessId: business.id });
        },

        async listMarketingCampaigns({ userId, runId = null, limit = 100 }) {
            const business = await database.getOrCreateBusinessForUser(userId);
            const rows = await database.listMarketingCampaignAssets({ userId, businessId: business.id, runId, limit });
            return rows.map((row) => ({
                id: Number(row.id), runId: Number(row.run_id), channel: row.channel, title: row.title,
                content: row.content, rationale: row.rationale || null, verifiedFacts: row.verified_facts || [],
                status: row.status, createdAt: row.created_at, updatedAt: row.updated_at
            }));
        },

        async listSchedules({ userId }) {
            const business = await database.getOrCreateBusinessForUser(userId);
            const rows = await database.listScheduledWorkflows({ userId, businessId: business.id });
            return rows.map(serializeSchedule);
        },

        async upsertSchedule({ userId, payload }) {
            const business = await database.getOrCreateBusinessForUser(userId);
            const schedule = validateSchedulePayload(payload, business.timezone);
            schedule.nextRunAt = computeNextRun(schedule, new Date());
            const saved = await database.upsertScheduledWorkflow({ userId, businessId: business.id, schedule });
            return serializeSchedule(saved);
        },

        async deleteSchedule({ userId, scheduleId }) {
            const business = await database.getOrCreateBusinessForUser(userId);
            return database.deleteScheduledWorkflow({ userId, businessId: business.id, scheduleId });
        },

        async updateReviewResponse({ userId, reviewId, response, action }) {
            const cleanResponse = String(response || '').trim();
            if (!cleanResponse || cleanResponse.length > 5000) {
                throw createWorkflowError('INVALID_REVIEW_RESPONSE', 'Enter a response between 1 and 5,000 characters.', 400);
            }
            if (!['save', 'approve', 'send'].includes(action)) {
                throw createWorkflowError('INVALID_REVIEW_ACTION', 'Choose a valid review response action.', 400);
            }

            if (action === 'send') {
                const existing = await database.updateReviewResponse({
                    userId,
                    reviewId,
                    response: cleanResponse,
                    status: 'approved'
                });
                if (!existing) throw createWorkflowError('REVIEW_NOT_FOUND', 'That review was not found.', 404);
                await reviewResponseConnector.send({
                    provider: existing.provider,
                    externalReviewId: existing.external_id,
                    response: cleanResponse,
                    businessId: existing.business_id
                });
                return database.updateReviewResponse({
                    userId,
                    reviewId,
                    response: cleanResponse,
                    status: 'sent'
                });
            }

            const updated = await database.updateReviewResponse({
                userId,
                reviewId,
                response: cleanResponse,
                status: action === 'approve' ? 'approved' : 'draft'
            });
            if (!updated) throw createWorkflowError('REVIEW_NOT_FOUND', 'That review was not found.', 404);
            return updated;
        },

        async getRun({ userId, runId }) {
            return database.getWorkflowRun({ userId, runId });
        },

        async listArtifacts({ userId, runId }) {
            const run = await database.getWorkflowRun({ userId, runId });
            if (!run) throw createWorkflowError('WORKFLOW_RUN_NOT_FOUND', 'That workflow run was not found.', 404);
            return (await database.listWorkflowArtifacts({ userId, runId })).map(serializeArtifact);
        },

        async getArtifact({ userId, artifactId }) {
            const artifact = await database.getWorkflowArtifact({ userId, artifactId });
            if (!artifact) throw createWorkflowError('WORKFLOW_ARTIFACT_NOT_FOUND', 'That workflow artifact was not found.', 404);
            return artifact;
        },

        async regenerateSection({ userId, runId, sectionKey }) {
            const run = await database.getWorkflowRun({ userId, runId });
            if (!run) throw createWorkflowError('WORKFLOW_RUN_NOT_FOUND', 'That workflow run was not found.', 404);
            return regenerateWeeklyMarketingSection({ userId, run, sectionKey, database, geminiService, reportService });
        },

        getConnectorConfiguration() {
            return {
                reviewResponsesConfigured: reviewResponseConnector.isConfigured,
                liveMarketing: liveDataCollector.configuration(),
                ai: geminiService.getPublicConfiguration()
            };
        }
    };
}

async function executeBySlug(context) {
    switch (context.workflow.slug) {
        case 'weekly-marketing':
            return executeMarketingOperatingWorkflow({
                ...context,
                analyticsEngine: context.analyticsEngine,
                marketingAiService: context.marketingAiService,
                competitorIntelligenceService: context.competitorIntelligenceService
            });
        case 'competitor-audit':
            return executeCompetitorAudit(context);
        case 'review-responder':
            return executeReviewResponder(context);
        case 'inventory-predictor':
            return executeInventoryPredictor(context);
        default:
            throw createWorkflowError('WORKFLOW_NOT_IMPLEMENTED', 'That workflow is not implemented.', 501);
    }
}

async function executeWeeklyMarketingLegacy({ userId, business, input, step, database, geminiService }) {
    const period = resolveComparablePeriod({ from: input.from, to: input.to });
    await step('resolve-business', async () => ({ businessId: Number(business.id), businessName: business.name }));
    const data = await step('fetch-business-data', () => database.getWeeklyMarketingData({
        userId,
        businessId: business.id,
        current: period.current,
        previous: period.previous
    }));
    await step('validate-data', async () => {
        if (Number(data.current.total_orders || 0) === 0) {
            throw createWorkflowError(
                'INSUFFICIENT_SALES_DATA',
                'No valid paid, completed, or fulfilled orders exist in the selected period. Import or connect order data and run the workflow again.',
                422
            );
        }
        return { validOrders: Number(data.current.total_orders), currency: data.business.currency };
    });
    const calculated = await step('calculate-metrics', async () => buildMarketingResult(data, period));
    const ai = await step('generate-insights', async () => generateGroundedInsights({
        geminiService,
        workflowName: 'Weekly Marketing',
        facts: calculated,
        instruction: [
            'Create practical marketing recommendations and a seven-day marketing plan.',
            'Use only the supplied factual results and calculated metrics.',
            'Clearly state when campaign, conversion, retention, or acquisition data is unavailable.',
            'Do not invent audience demographics, channels, budgets, competitors, prices, products, or performance.'
        ].join(' ')
    }));
    const recordsAnalyzed = sumRecordCounts(data.recordCounts);
    return {
        period: period.current,
        dataRetrievedAt: data.retrievedAt,
        recordsAnalyzed,
        output: {
            workflow: 'weekly-marketing',
            trustworthy: true,
            business: serializeBusiness(data.business),
            dataPeriod: serializePeriod(period.current),
            previousPeriod: serializePeriod(period.previous),
            recordsAnalyzed,
            factualResults: calculated.factualResults,
            calculatedMetrics: calculated.calculatedMetrics,
            aiInsights: ai
        }
    };
}

async function executeCompetitorAudit({ userId, business, step, database, geminiService }) {
    await step('resolve-business', async () => ({ businessId: Number(business.id), businessName: business.name }));
    const data = await step('fetch-competitor-data', () => database.getCompetitorAuditData({
        userId,
        businessId: business.id
    }));
    const sourced = await step('validate-data', async () => {
        if (data.competitors.length === 0) {
            throw createWorkflowError(
                'COMPETITOR_INTEGRATION_REQUIRED',
                'No competitors are configured. Import competitor records and snapshots from a legitimate API or connected data source before running this audit.',
                422
            );
        }
        const available = data.competitors.filter((item) => item.snapshot_id && item.retrieved_at);
        if (available.length === 0) {
            throw createWorkflowError(
                'COMPETITOR_DATA_UNAVAILABLE',
                'Competitors are configured, but no retrieved snapshots are available. Connect a legitimate competitor-data API or import current sourced snapshots.',
                422
            );
        }
        return available;
    });
    const comparison = await step('compare-competitors', async () => buildCompetitorComparison(sourced));
    const ai = await step('generate-insights', async () => generateGroundedInsights({
        geminiService,
        workflowName: 'Competitor Audit',
        facts: comparison,
        instruction: [
            'Compare pricing, products, positioning, and offers only when those fields exist in the supplied snapshots.',
            'Generate actionable positioning and response recommendations.',
            'Cite competitor names and retrieval timestamps in the analysis.',
            'Do not infer missing prices, offers, market share, customer sentiment, or product quality.'
        ].join(' ')
    }));
    const dates = sourced.map((item) => new Date(item.retrieved_at)).filter((date) => !Number.isNaN(date.getTime()));
    const period = dates.length > 0
        ? { from: new Date(Math.min(...dates)), to: new Date(Math.max(...dates)) }
        : null;
    return {
        period,
        dataRetrievedAt: data.retrievedAt,
        recordsAnalyzed: sourced.length,
        output: {
            workflow: 'competitor-audit',
            trustworthy: true,
            business: serializeBusiness(data.business),
            dataPeriod: period ? serializePeriod(period) : null,
            recordsAnalyzed: sourced.length,
            factualResults: comparison.factualResults,
            calculatedMetrics: comparison.calculatedMetrics,
            aiInsights: ai
        }
    };
}

async function executeReviewResponder({ userId, business, step, database, geminiService }) {
    await step('resolve-business', async () => ({ businessId: Number(business.id), businessName: business.name }));
    const data = await step('fetch-reviews', () => database.getReviewResponderData({
        userId,
        businessId: business.id,
        limit: MAX_REVIEW_BATCH
    }));
    await step('validate-data', async () => {
        if (data.reviews.length === 0) {
            throw createWorkflowError(
                'REVIEW_DATA_UNAVAILABLE',
                'No unanswered published reviews are available. Connect a review provider or import real review records, then run the workflow again.',
                422
            );
        }
        return { reviewCount: data.reviews.length };
    });
    const analyses = await step('analyze-reviews', async () => data.reviews.map(analyzeReview));
    const generated = await step('generate-responses', async () => generateReviewDrafts({
        geminiService,
        reviews: data.reviews,
        analyses,
        businessName: data.business.name
    }));
    const draftsToSave = generated.drafts
        .filter((draft) => draft.response)
        .map((draft) => ({
            id: draft.id,
            externalId: draft.externalId,
            response: draft.response
        }));
    if (draftsToSave.length > 0) {
        await database.saveReviewDrafts({ userId, businessId: business.id, drafts: draftsToSave });
    }
    const publishedDates = data.reviews.map((review) => new Date(review.published_at));
    const period = {
        from: new Date(Math.min(...publishedDates)),
        to: new Date(Math.max(...publishedDates))
    };
    return {
        period,
        dataRetrievedAt: data.retrievedAt,
        recordsAnalyzed: data.reviews.length,
        output: {
            workflow: 'review-responder',
            trustworthy: true,
            business: serializeBusiness(data.business),
            dataPeriod: serializePeriod(period),
            recordsAnalyzed: data.reviews.length,
            factualResults: data.reviews.map((review) => ({
                id: Number(review.id),
                externalId: review.external_id,
                provider: review.provider,
                rating: review.rating === null ? null : Number(review.rating),
                reviewText: review.review_text,
                customerName: review.customer_name || null,
                publishedAt: review.published_at,
                sourceUrl: review.source_url || null
            })),
            calculatedMetrics: analyses,
            aiInsights: generated.ai,
            responseDrafts: generated.drafts
        }
    };
}

async function executeInventoryPredictor({ userId, business, input, step, database, geminiService }) {
    const period = resolveInventoryPeriod(input);
    await step('resolve-business', async () => ({ businessId: Number(business.id), businessName: business.name }));
    const data = await step('fetch-inventory-data', () => database.getInventoryData({
        userId,
        businessId: business.id,
        current: period.current,
        previous: period.previous
    }));
    await step('validate-data', async () => {
        if (data.products.length === 0) {
            throw createWorkflowError(
                'INVENTORY_DATA_UNAVAILABLE',
                'No active products are available. Import product inventory and historical order items before running this prediction.',
                422
            );
        }
        const productsWithStock = data.products.filter((product) => product.current_stock !== null);
        if (productsWithStock.length === 0) {
            throw createWorkflowError(
                'CURRENT_STOCK_UNAVAILABLE',
                'Product records exist, but current stock is missing. Import current inventory values before running this prediction.',
                422
            );
        }
        const productsWithDemandHistory = productsWithStock.filter((product) =>
            Number(product.order_records || 0) > 0
            || Number(product.units_sold || 0) > 0
            || Number(product.previous_units_sold || 0) > 0);
        if (productsWithDemandHistory.length === 0) {
            throw createWorkflowError(
                'INSUFFICIENT_INVENTORY_HISTORY',
                'Inventory records exist, but no valid paid, completed, or fulfilled order-item history is available for forecasting. Import historical sales tied to products and run the workflow again.',
                422
            );
        }
        return {
            products: data.products.length,
            productsWithStock: productsWithStock.length,
            productsWithDemandHistory: productsWithDemandHistory.length
        };
    });
    const forecasts = await step('calculate-forecast', async () => data.products.map((product) =>
        calculateInventoryForecast(product, period.days, 7)));
    const demoProducts = data.products.filter((product) => product.metadata?.orexis_inventory_demo === INVENTORY_DEMO_VERSION).length;
    const dataMode = demoProducts === data.products.length && data.products.length > 0 ? 'demo' : demoProducts > 0 ? 'mixed' : 'production';
    const ai = await step('generate-insights', async () => generateGroundedInsights({
        geminiService,
        workflowName: 'Inventory Predictor',
        facts: { periodDays: period.days, forecasts },
        instruction: [
            'Explain stock risks and prioritize products using only the verified calculated forecast.',
            'Use the calculated recommendedReorderQuantity when it is available; never invent quantities or business facts.',
            'Do not create reorder quantities when lead time, demand history, or current stock is unavailable.',
            'State confidence and limitations explicitly.'
        ].join(' ')
    }));
    return {
        period: period.current,
        dataRetrievedAt: data.retrievedAt,
        recordsAnalyzed: data.recordsAnalyzed,
        output: {
            workflow: 'inventory-predictor',
            trustworthy: true,
            business: serializeBusiness(data.business),
            dataPeriod: serializePeriod(period.current),
            previousPeriod: serializePeriod(period.previous),
            recordsAnalyzed: data.recordsAnalyzed,
            dataMode,
            sourceCoverage: data.sources,
            methodology: {
                baselineDemand: '55% recent 28-day demand + 25% previous 28-day demand + 20% same-period demand one year earlier when available',
                demandSignals: 'Verified promotion, seasonal-event, online-intent, and imported forecast-weather factors are applied only when present',
                availableStock: 'Warehouse current stock minus reserved and damaged stock plus returned stock',
                projectedDemand: 'Grounded projected daily demand × 7-day forecast horizon',
                reorderPoint: 'Maximum of configured reorder point and lead-time demand plus safety stock',
                recommendedReorderQuantity: 'Target stock minus available and incoming stock, rounded to the configured reorder lot size'
            },
            factualResults: data.products.map((product) => ({
                productId: Number(product.product_id),
                productName: product.product_name,
                sku: product.sku || null,
                currentStock: product.current_stock === null ? null : Number(product.current_stock),
                reservedStock: Number(product.reserved_stock || 0),
                incomingStock: Number(product.incoming_stock || 0),
                supplierName: product.supplier_name || null,
                supplierReliabilityScore: product.supplier_reliability_score === null ? null : Number(product.supplier_reliability_score),
                unitsSold: Number(product.units_sold || 0),
                previousUnitsSold: Number(product.previous_units_sold || 0),
                yearAgoUnitsSold: Number(product.year_ago_units_sold || 0),
                activePromotions: product.active_promotions || null,
                seasonalEvents: product.seasonal_events || null
            })),
            calculatedMetrics: forecasts,
            aiInsights: ai
        }
    };
}

function createStepExecutor({ database, onEvent, runId, workflow, startedAt, deadlineAt }) {
    const stepIndex = new Map(workflow.steps.map((definition, index) => [definition.key, index]));
    let activeStep = null;
    const log = async (level, message, metadata = {}) => {
        const entry = await database.appendWorkflowLog?.({ runId, level, stepKey: activeStep, message, metadata }).catch(() => null);
        emit(onEvent, 'log', {
            runId: Number(runId), level, stepKey: activeStep, message,
            metadata, createdAt: entry?.created_at || new Date().toISOString()
        });
        return entry;
    };
    const updateProgress = async (stepKey, status) => {
        const index = stepIndex.get(stepKey) ?? 0;
        const completedUnits = status === 'completed' ? index + 1 : index;
        const percentage = Math.max(0, Math.min(99, Math.round((completedUnits / workflow.steps.length) * 100)));
        const elapsed = Math.max(1000, Date.now() - startedAt);
        const unitsDone = Math.max(1, completedUnits || index + 0.35);
        const remainingMs = Math.max(0, Math.round((elapsed / unitsDone) * (workflow.steps.length - completedUnits)));
        const estimatedCompletionAt = new Date(Date.now() + remainingMs).toISOString();
        await database.updateWorkflowProgress?.({ runId, percentage, currentStep: stepKey, estimatedCompletionAt }).catch(() => {});
        emit(onEvent, 'progress', { runId: Number(runId), currentStep: stepKey, percentage, estimatedCompletionAt });
    };
    const step = async function executeStep(stepKey, operation) {
        assertWorkflowDeadline(deadlineAt);
        activeStep = stepKey;
        await updateProgress(stepKey, 'running');
        await database.updateWorkflowStep({ runId, stepKey, status: 'running' });
        await log('info', `${workflow.steps.find((item) => item.key === stepKey)?.title || stepKey} started.`);
        emit(onEvent, 'step', { runId: Number(runId), stepKey, status: 'running' });
        try {
            const output = await operation();
            assertWorkflowDeadline(deadlineAt);
            await database.updateWorkflowStep({ runId, stepKey, status: 'completed', output: summarizeStepOutput(output) });
            await updateProgress(stepKey, 'completed');
            await log('info', `${workflow.steps.find((item) => item.key === stepKey)?.title || stepKey} completed.`);
            emit(onEvent, 'step', { runId: Number(runId), stepKey, status: 'completed' });
            return output;
        } catch (error) {
            await database.updateWorkflowStep({ runId, stepKey, status: 'failed', errorMessage: error.publicMessage || error.message }).catch(() => {});
            await log('error', error.publicMessage || error.message || 'This step failed.', { code: error.code || null });
            emit(onEvent, 'step', { runId: Number(runId), stepKey, status: 'failed', error: error.publicMessage || 'This step failed.' });
            throw error;
        }
    };
    return { step, log };
}

function buildMarketingResult(data, period) {
    const currentRevenue = Number(data.current.total_revenue_minor || 0);
    const previousRevenue = Number(data.previous.total_revenue_minor || 0);
    const currentOrders = Number(data.current.total_orders || 0);
    const previousOrders = Number(data.previous.total_orders || 0);
    const uniqueCustomers = Number(data.current.unique_customers || 0);
    const campaignRecords = Number(data.campaign.records || 0);
    const conversions = campaignRecords > 0 ? Number(data.campaign.conversions || 0) : null;
    const visitors = campaignRecords > 0 ? Number(data.campaign.visitors || 0) : null;
    const campaignSpend = campaignRecords > 0 ? Number(data.campaign.spend_minor || 0) : null;
    const campaignRevenue = campaignRecords > 0 ? Number(data.campaign.attributed_revenue_minor || 0) : null;

    return {
        factualResults: {
            currency: data.business.currency,
            totalRevenueMinor: currentRevenue,
            totalOrders: currentOrders,
            uniqueCustomers,
            topProducts: data.topProducts.map((product) => ({
                productId: Number(product.product_id),
                productName: product.product_name,
                sku: product.sku || null,
                unitsSold: Number(product.units_sold || 0),
                revenueMinor: Number(product.revenue_minor || 0),
                orderCount: Number(product.order_count || 0)
            })),
            productSalesVolume: data.topProducts.reduce((sum, product) => sum + Number(product.units_sold || 0), 0),
            dailyTrend: data.daily.map((row) => ({
                date: row.day,
                orders: Number(row.orders || 0),
                revenueMinor: Number(row.revenue_minor || 0)
            })),
            customerTrend: {
                newCustomers: Number(data.customerTrend.new_customers || 0),
                activeCustomers: Number(data.customerTrend.active_customers || 0),
                previousNewCustomers: Number(data.customerTrend.previous_new_customers || 0)
            },
            campaignDataAvailable: campaignRecords > 0,
            campaign: campaignRecords > 0 ? {
                records: campaignRecords,
                spendMinor: campaignSpend,
                attributedRevenueMinor: campaignRevenue,
                impressions: Number(data.campaign.impressions || 0),
                clicks: Number(data.campaign.clicks || 0),
                visitors,
                leads: Number(data.campaign.leads || 0),
                conversions,
                retrievedAt: data.campaign.retrieved_at
            } : null,
            periodDays: period.days
        },
        calculatedMetrics: {
            averageOrderValueMinor: safeDivide(currentRevenue, currentOrders),
            revenuePerCustomerMinor: safeDivide(currentRevenue, uniqueCustomers),
            revenueGrowthPercentage: growthPercentage(currentRevenue, previousRevenue),
            orderGrowthPercentage: growthPercentage(currentOrders, previousOrders),
            customerGrowthPercentage: growthPercentage(uniqueCustomers, Number(data.previous.unique_customers || 0)),
            conversionRatePercentage: conversions === null || visitors === null ? null : safeDivide(conversions * 100, visitors),
            campaignReturnOnSpend: campaignSpend && campaignSpend > 0 ? safeDivide(campaignRevenue, campaignSpend) : null
        }
    };
}

function buildOverview(data, period) {
    const marketing = buildMarketingResult(data, period);
    const crm = data.crm;
    const purchasingCustomers = Number(crm.purchasing_customers || 0);
    const repeatCustomers = Number(crm.repeat_customers || 0);
    return {
        business: serializeBusiness(data.business),
        dataPeriod: serializePeriod(period.current),
        previousPeriod: serializePeriod(period.previous),
        dataRetrievedAt: data.retrievedAt,
        recordsAnalyzed: sumRecordCounts(data.recordCounts),
        dataAvailability: {
            orderRecords: Number(data.recordCounts.order_records || 0),
            orderItemRecords: Number(data.recordCounts.item_records || 0),
            campaignRecords: Number(data.recordCounts.campaign_records || 0),
            customerRecords: Number(data.crm.total_customers || 0)
        },
        marketing: marketing.factualResults,
        analytics: marketing.calculatedMetrics,
        crm: {
            totalCustomers: Number(crm.total_customers || 0),
            activeCustomers: Number(crm.active_customers || 0),
            inactive30Days: Number(crm.inactive_30_days || 0),
            followupsDue: Number(crm.followups_due || 0),
            repeatPurchaseRatePercentage: purchasingCustomers > 0
                ? safeDivide(repeatCustomers * 100, purchasingCustomers)
                : null,
            customers: data.customers.map((customer) => ({
                id: Number(customer.id),
                externalId: customer.external_id,
                name: customer.name || null,
                email: customer.email || null,
                status: customer.status,
                firstSeenAt: customer.first_seen_at,
                lastActivityAt: customer.last_activity_at,
                orderCount: Number(customer.order_count || 0),
                lifetimeValueMinor: Number(customer.lifetime_value_minor || 0),
                lastOrderAt: customer.last_order_at,
                needsReviewFollowup: Boolean(customer.needs_review_followup)
            }))
        }
    };
}

function buildCompetitorComparison(rows) {
    const factualResults = rows.map((row) => ({
        competitorId: Number(row.competitor_id),
        competitorName: row.name,
        retrievedAt: row.retrieved_at,
        sourceName: row.source_name || row.configured_source_name || null,
        sourceUrl: row.source_url || row.configured_source_url || null,
        currency: row.currency || null,
        products: Array.isArray(row.products) ? row.products : [],
        offers: Array.isArray(row.offers) ? row.offers : [],
        positioning: row.positioning || null
    }));
    const priceGroups = new Map();
    for (const competitor of factualResults) {
        for (const product of competitor.products) {
            const name = String(product?.name || product?.product || '').trim();
            const price = Number(product?.priceMinor ?? product?.price_minor);
            if (!name || !Number.isFinite(price) || price < 0) continue;
            const key = name.toLocaleLowerCase('en-US');
            const entries = priceGroups.get(key) || [];
            entries.push({ competitorName: competitor.competitorName, productName: name, priceMinor: price, currency: competitor.currency });
            priceGroups.set(key, entries);
        }
    }
    const comparablePrices = [...priceGroups.values()]
        .filter((entries) => entries.length >= 2 && new Set(entries.map((entry) => entry.currency)).size === 1)
        .map((entries) => {
            const prices = entries.map((entry) => entry.priceMinor);
            return {
                productName: entries[0].productName,
                currency: entries[0].currency,
                lowestPriceMinor: Math.min(...prices),
                highestPriceMinor: Math.max(...prices),
                priceRangeMinor: Math.max(...prices) - Math.min(...prices),
                competitors: entries
            };
        });
    return {
        factualResults,
        calculatedMetrics: {
            competitorsWithCurrentSnapshots: factualResults.length,
            comparableProductGroups: comparablePrices
        }
    };
}

function analyzeReview(review) {
    const text = String(review.review_text || '');
    const normalized = text.toLocaleLowerCase('en-US');
    const positiveWords = ['great', 'excellent', 'amazing', 'love', 'helpful', 'fast', 'perfect', 'good', 'happy', 'recommend'];
    const negativeWords = ['bad', 'poor', 'slow', 'broken', 'late', 'refund', 'problem', 'issue', 'disappointed', 'worst', 'missing'];
    const positiveScore = positiveWords.filter((word) => normalized.includes(word)).length;
    const negativeScore = negativeWords.filter((word) => normalized.includes(word)).length;
    const rating = review.rating === null ? null : Number(review.rating);
    let sentiment = 'neutral';
    if ((rating !== null && rating >= 4) || positiveScore > negativeScore) sentiment = 'positive';
    if ((rating !== null && rating <= 2) || negativeScore > positiveScore) sentiment = 'negative';
    const concerns = [];
    for (const [label, terms] of Object.entries({
        delivery: ['late', 'delivery', 'shipping', 'arrived'],
        product: ['broken', 'quality', 'missing', 'damaged', 'product'],
        billing: ['refund', 'charged', 'payment', 'price'],
        support: ['support', 'reply', 'response', 'service', 'staff']
    })) {
        if (terms.some((term) => normalized.includes(term))) concerns.push(label);
    }
    return {
        reviewId: Number(review.id),
        externalId: review.external_id,
        sentiment,
        concerns,
        rating
    };
}

async function generateReviewDrafts({ geminiService, reviews, analyses, businessName }) {
    const factualPayload = reviews.map((review) => ({
        id: Number(review.id),
        externalId: review.external_id,
        provider: review.provider,
        rating: review.rating === null ? null : Number(review.rating),
        reviewText: review.review_text,
        analysis: analyses.find((item) => item.reviewId === Number(review.id))
    }));
    const ai = await generateGroundedInsights({
        geminiService,
        workflowName: 'Review Responder',
        facts: { businessName, reviews: factualPayload },
        instruction: [
            'Return only valid JSON with this shape: {"drafts":[{"id":number,"externalId":string,"response":string}]}.',
            'Draft one concise professional response for every supplied review.',
            'Use only facts in each review. Do not promise refunds, replacements, contact, investigation, or actions that are not confirmed.',
            'Do not include private data. Keep each response under 1,000 characters.'
        ].join(' '),
        expectJson: true
    });
    if (ai.status !== 'generated' || !ai.data || !Array.isArray(ai.data.drafts)) {
        return { ai, drafts: factualPayload.map((review) => ({ id: review.id, externalId: review.externalId, response: null })) };
    }
    const allowed = new Map(factualPayload.map((review) => [`${review.id}:${review.externalId}`, review]));
    const drafts = ai.data.drafts
        .map((draft) => ({
            id: Number(draft?.id),
            externalId: String(draft?.externalId || ''),
            response: String(draft?.response || '').trim().slice(0, 1000)
        }))
        .filter((draft) => draft.response && allowed.has(`${draft.id}:${draft.externalId}`));
    const byKey = new Map(drafts.map((draft) => [`${draft.id}:${draft.externalId}`, draft]));
    return {
        ai,
        drafts: factualPayload.map((review) => byKey.get(`${review.id}:${review.externalId}`) || {
            id: review.id,
            externalId: review.externalId,
            response: null
        })
    };
}

async function generateGroundedInsights({ geminiService, workflowName, facts, instruction, expectJson = false }) {
    const configuration = geminiService.getPublicConfiguration();
    if (!configuration.isConfigured) {
        return {
            status: 'unavailable',
            reason: 'GEMINI_API_KEY is not configured. Factual and calculated results remain available without AI recommendations.'
        };
    }
    const serialized = JSON.stringify(facts);
    if (Buffer.byteLength(serialized, 'utf8') > MAX_AI_FACT_BYTES) {
        return {
            status: 'unavailable',
            reason: 'The verified fact payload is too large for safe AI analysis. Narrow the date range and run again.'
        };
    }
    const prompt = [
        `Workflow: ${workflowName}`,
        'The JSON below contains the only verified facts you may use.',
        'Keep factual database results, calculated metrics, and recommendations clearly separated.',
        'Never invent or infer missing business facts.',
        instruction,
        'VERIFIED_JSON:',
        serialized
    ].join('\n\n');
    try {
        const response = await geminiService.generateReply([{ role: 'user', content: prompt }]);
        if (!expectJson) {
            return { status: 'generated', model: response.model, content: response.content };
        }
        const data = parseJsonResponse(response.content);
        if (!data) {
            return {
                status: 'unavailable',
                reason: 'The AI provider returned an invalid structured response, so no draft was saved.'
            };
        }
        return { status: 'generated', model: response.model, data };
    } catch (error) {
        return {
            status: 'unavailable',
            code: error.code || 'AI_PROVIDER_ERROR',
            reason: error.publicMessage || 'AI analysis is temporarily unavailable.'
        };
    }
}

function resolveInventoryPeriod(input) {
    if (input?.from || input?.to) return resolveComparablePeriod({ from: input.from, to: input.to });
    const to = new Date();
    const from = new Date(to.getTime() - (28 * 24 * 60 * 60 * 1000));
    const previousFrom = new Date(from.getTime() - (28 * 24 * 60 * 60 * 1000));
    return {
        current: { from, to },
        previous: { from: previousFrom, to: from },
        days: 28
    };
}

function createReviewResponseConnector({ env, fetchImpl }) {
    const endpoint = String(env.REVIEW_RESPONSE_API_URL || '').trim();
    const token = String(env.REVIEW_RESPONSE_API_TOKEN || '').trim();
    const timeoutMs = parseBoundedInteger(env.REVIEW_RESPONSE_TIMEOUT_MS, 10_000, 1_000, 30_000);
    return {
        isConfigured: Boolean(endpoint),
        async send(payload) {
            if (!endpoint) {
                throw createWorkflowError(
                    'REVIEW_RESPONSE_INTEGRATION_REQUIRED',
                    'The response is approved, but sending requires REVIEW_RESPONSE_API_URL to be connected to your review provider.',
                    409
                );
            }
            if (typeof fetchImpl !== 'function') {
                throw createWorkflowError('REVIEW_RESPONSE_UNAVAILABLE', 'The review provider cannot be reached by this server runtime.', 500);
            }
            const controller = new AbortController();
            const timeout = setTimeout(() => controller.abort(), timeoutMs);
            try {
                const response = await fetchImpl(endpoint, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        Accept: 'application/json',
                        ...(token ? { Authorization: `Bearer ${token}` } : {})
                    },
                    body: JSON.stringify(payload),
                    signal: controller.signal
                });
                if (!response.ok) {
                    throw createWorkflowError('REVIEW_RESPONSE_PROVIDER_ERROR', 'The review provider rejected the response. The approved draft was kept.', 502);
                }
            } catch (error) {
                if (error.name === 'AbortError') {
                    throw createWorkflowError('REVIEW_RESPONSE_TIMEOUT', 'The review provider timed out. The approved draft was kept.', 504);
                }
                if (error.code) throw error;
                throw createWorkflowError('REVIEW_RESPONSE_PROVIDER_ERROR', 'The review provider could not be reached. The approved draft was kept.', 502);
            } finally {
                clearTimeout(timeout);
            }
        }
    };
}

function parseJsonResponse(content) {
    const text = String(content || '').trim();
    const unfenced = text.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
    try {
        return JSON.parse(unfenced);
    } catch {
        const start = unfenced.indexOf('{');
        const end = unfenced.lastIndexOf('}');
        if (start < 0 || end <= start) return null;
        try {
            return JSON.parse(unfenced.slice(start, end + 1));
        } catch {
            return null;
        }
    }
}

function serializeSchedule(row) {
    return {
        id: Number(row.id),
        businessId: Number(row.business_id),
        workflowSlug: row.workflow_slug,
        scheduleKind: row.schedule_kind,
        cadence: row.cadence,
        runHour: Number(row.run_hour),
        runMinute: Number(row.run_minute),
        dayOfWeek: row.day_of_week === null ? null : Number(row.day_of_week),
        dayOfMonth: row.day_of_month === null ? null : Number(row.day_of_month),
        timezone: row.timezone,
        input: row.input || {},
        enabled: Boolean(row.enabled),
        nextRunAt: row.next_run_at,
        lastRunAt: row.last_run_at || null,
        lastRunId: row.last_run_id === null ? null : Number(row.last_run_id),
        lastStatus: row.last_status || null,
        lastError: row.last_error || null,
        createdAt: row.created_at,
        updatedAt: row.updated_at
    };
}

function serializeWorkflowDefinition(workflow) {
    return {
        slug: workflow.slug,
        name: workflow.name,
        description: workflow.description,
        resultView: workflow.resultView,
        steps: workflow.steps.map((step) => ({ key: step.key, title: step.title }))
    };
}

function serializeBusiness(business) {
    return {
        id: Number(business.id),
        name: business.name,
        currency: business.currency,
        timezone: business.timezone
    };
}

function serializePeriod(period) {
    return {
        from: new Date(period.from).toISOString(),
        to: new Date(period.to).toISOString()
    };
}

function serializeRun(run) {
    return {
        id: Number(run.id),
        businessId: run.business_id === null || run.business_id === undefined ? null : Number(run.business_id),
        workflowSlug: run.workflow_slug,
        workflowName: run.workflow_name,
        status: run.status,
        input: run.input || {},
        output: run.output || null,
        error: run.error_message || null,
        dataPeriodStart: run.data_period_start || null,
        dataPeriodEnd: run.data_period_end || null,
        dataRetrievedAt: run.data_retrieved_at || null,
        recordsAnalyzed: Number(run.records_analyzed || 0),
        durationMs: run.duration_ms === null || run.duration_ms === undefined ? null : Number(run.duration_ms),
        progressPercentage: Number(run.progress_percentage || 0),
        currentStep: run.current_step || null,
        estimatedCompletionAt: run.estimated_completion_at || null,
        createdAt: run.created_at,
        startedAt: run.started_at || null,
        completedAt: run.completed_at || null,
        steps: Array.isArray(run.steps) ? run.steps.map((step) => ({
            key: step.step_key,
            title: step.step_title,
            order: Number(step.step_order),
            status: step.status,
            error: step.error_message || null
        })) : undefined,
        logs: Array.isArray(run.logs) ? run.logs.map((entry) => ({
            id: Number(entry.id), level: entry.level, stepKey: entry.step_key || null,
            message: entry.message, metadata: entry.metadata || {}, createdAt: entry.created_at
        })) : undefined,
        artifacts: Array.isArray(run.artifacts) ? run.artifacts.map(serializeArtifact) : undefined
    };
}

function summarizeStepOutput(output) {
    if (!output || typeof output !== 'object') return output;
    if (Array.isArray(output)) return { records: output.length };
    if (output.business && output.retrievedAt) {
        return { retrievedAt: output.retrievedAt, businessId: Number(output.business.id) };
    }
    return output;
}

function sumRecordCounts(counts) {
    return Object.values(counts || {}).reduce((sum, value) => sum + Number(value || 0), 0);
}

function startWorkflowHeartbeat({ database, runId, businessId, staleAfterSeconds }) {
    const intervalMs = Math.max(1000, Math.min(30000, Math.floor(staleAfterSeconds * 1000 / 3)));
    const heartbeat = setInterval(() => {
        Promise.resolve(database.touchWorkflowRun?.({ runId, businessId }))
            .then((touched) => {
                if (!touched) clearInterval(heartbeat);
            })
            .catch(() => {});
    }, intervalMs);
    heartbeat.unref?.();
    return heartbeat;
}

function withWorkflowExecutionTimeout(operation, maxRunSeconds) {
    let timeout = null;
    const timeoutPromise = new Promise((resolve, reject) => {
        void resolve;
        timeout = setTimeout(() => {
            reject(createWorkflowError(
                'WORKFLOW_TIMEOUT',
                'The workflow exceeded its maximum execution time and was safely stopped. Run it again after checking the connected data provider.',
                504
            ));
        }, maxRunSeconds * 1000);
        timeout.unref?.();
    });
    return Promise.race([Promise.resolve().then(operation), timeoutPromise])
        .finally(() => { if (timeout) clearTimeout(timeout); });
}

function assertWorkflowDeadline(deadlineAt) {
    if (Number.isFinite(deadlineAt) && Date.now() >= deadlineAt) {
        throw createWorkflowError(
            'WORKFLOW_TIMEOUT',
            'The workflow exceeded its maximum execution time and was safely stopped. Run it again after checking the connected data provider.',
            504
        );
    }
}

function emit(callback, type, payload) {
    try {
        callback({ type, ...payload, timestamp: new Date().toISOString() });
    } catch {
        // Streaming disconnects must not interrupt database execution.
    }
}

function createWorkflowError(code, publicMessage, statusCode = 500) {
    const error = new Error(publicMessage);
    error.code = code;
    error.publicMessage = publicMessage;
    error.statusCode = statusCode;
    return error;
}

function parseBoundedInteger(value, fallback, minimum, maximum) {
    const parsed = Number.parseInt(value, 10);
    return Number.isInteger(parsed) && parsed >= minimum && parsed <= maximum ? parsed : fallback;
}

module.exports = {
    buildMarketingResult,
    buildOverview,
    createWorkflowError,
    createWorkflowService
};
