import React from 'react';
import { createRoot } from 'react-dom/client';
import Hyperspeed from './Hyperspeed.jsx';
import { hyperspeedPresets } from './HyperSpeedPresets.js';

const mount = document.getElementById('outcomeHyperspeed');
if (mount && mount.dataset.reactBitsMounted !== 'true') {
  mount.dataset.reactBitsMounted = 'true';
  createRoot(mount).render(
    React.createElement(Hyperspeed, { effectOptions: hyperspeedPresets.three })
  );
}
