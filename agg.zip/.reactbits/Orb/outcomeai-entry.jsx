import React from 'react';
import { createRoot } from 'react-dom/client';
import Orb from './Orb.jsx';

const mount = document.getElementById('outcomeAgentOrb');
const agentView = mount?.closest('[data-view="agent"]');
const shell = mount?.closest('.agent-chat-shell');
let resizeObserver;

function mountOfficialOrb() {
  if (!mount || mount.dataset.reactBitsMounted === 'true') return;
  if (agentView?.hidden || mount.clientWidth === 0 || mount.clientHeight === 0) return;
  mount.dataset.reactBitsMounted = 'true';
  createRoot(mount).render(React.createElement(Orb));
  resizeObserver = new ResizeObserver(() => window.dispatchEvent(new Event('resize')));
  resizeObserver.observe(mount);
}

function tryMountOfficialOrb() {
  requestAnimationFrame(() => requestAnimationFrame(mountOfficialOrb));
}

if (agentView) {
  new MutationObserver(tryMountOfficialOrb).observe(agentView, { attributes: true, attributeFilter: ['hidden'] });
}
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', tryMountOfficialOrb, { once: true });
} else {
  tryMountOfficialOrb();
}

if (mount && shell) {
  shell.addEventListener('pointermove', event => {
    mount.dispatchEvent(new MouseEvent('mousemove', {
      clientX: event.clientX,
      clientY: event.clientY,
      bubbles: false
    }));
  });
  shell.addEventListener('pointerleave', () => {
    mount.dispatchEvent(new MouseEvent('mouseleave', { bubbles: false }));
  });
}
