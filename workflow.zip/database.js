'use strict';

const fs = require('node:fs/promises');
const path = require('node:path');
const { Pool } = require('pg');

function createDatabaseFromEnvironment(env = process.env) {
    const connectionString = env.DATABASE_URL?.trim();
    if (!connectionString) {
        throw new Error('DATABASE_URL is required. Copy .env.example to .env and configure PostgreSQL.');
    }

    const pool = new Pool({
        connectionString,
        max: parsePoolSize(env.DATABASE_POOL_MAX || '10'),
        ssl: env.DATABASE_SSL === 'true'
            ? { rejectUnauthorized: env.DATABASE_SSL_REJECT_UNAUTHORIZED !== 'false' }
            : undefined
    });

    pool.on('error', (error) => {
        console.error('Unexpected PostgreSQL pool error:', error.message);
    });

    return createUserStore(pool);
}

function createUserStore(pool) {
    return {
        async initialize() {
            const schemaPath = path.join(__dirname, 'database', 'schema.sql');
            const schema = await fs.readFile(schemaPath, 'utf8');
            await pool.query(schema);
        },

        async healthCheck() {
            await pool.query('SELECT 1');
        },

        async findUserByEmail(email) {
            const result = await pool.query(
                `SELECT id, username, email, password_hash
                 FROM users
                 WHERE LOWER(email) = LOWER($1)
                 LIMIT 1`,
                [email]
            );
            return result.rows[0] || null;
        },

        async createUser({ username, email, passwordHash }) {
            const result = await pool.query(
                `INSERT INTO users (username, email, password_hash)
                 VALUES ($1, $2, $3)
                 RETURNING id, username, email`,
                [username, email, passwordHash]
            );
            return result.rows[0];
        },

        async getBillingProfile(userId) {
            const result = await pool.query(
                `UPDATE users
                 SET current_plan = CASE
                         WHEN plan_expires_at IS NOT NULL AND plan_expires_at <= NOW() THEN 'free'
                         ELSE current_plan
                     END,
                     plan_expires_at = CASE
                         WHEN plan_expires_at IS NOT NULL AND plan_expires_at <= NOW() THEN NULL
                         ELSE plan_expires_at
                     END
                 WHERE id = $1
                 RETURNING current_plan, plan_expires_at`,
                [userId]
            );
            return result.rows[0] || { current_plan: 'free', plan_expires_at: null };
        },

        async createPendingPayment({ userId, provider, planId, providerOrderId, amountMinor, currency }) {
            const result = await pool.query(
                `INSERT INTO payments (
                    user_id, provider, plan_id, provider_order_id, amount_minor, currency, status
                 ) VALUES ($1, $2, $3, $4, $5, $6, 'pending')
                 RETURNING id, user_id, provider, plan_id, provider_order_id,
                           provider_payment_id, amount_minor, currency, status`,
                [userId, provider, planId, providerOrderId, amountMinor, currency]
            );
            return result.rows[0];
        },

        async findPaymentByProviderOrder({ userId, provider, providerOrderId }) {
            const result = await pool.query(
                `SELECT id, user_id, provider, plan_id, provider_order_id,
                        provider_payment_id, amount_minor, currency, status
                 FROM payments
                 WHERE user_id = $1 AND provider = $2 AND provider_order_id = $3
                 LIMIT 1`,
                [userId, provider, providerOrderId]
            );
            return result.rows[0] || null;
        },

        async completePayment({
            userId,
            provider,
            planId,
            providerOrderId,
            providerPaymentId,
            amountMinor,
            currency
        }) {
            const client = await pool.connect();
            try {
                await client.query('BEGIN');
                const paymentResult = await client.query(
                    `SELECT id, user_id, plan_id, amount_minor, currency, status, provider_payment_id
                     FROM payments
                     WHERE user_id = $1 AND provider = $2 AND provider_order_id = $3
                     FOR UPDATE`,
                    [userId, provider, providerOrderId]
                );
                const payment = paymentResult.rows[0];
                if (!payment) {
                    const error = new Error('Pending payment was not found.');
                    error.code = 'PAYMENT_NOT_FOUND';
                    throw error;
                }
                if (payment.plan_id !== planId
                    || Number(payment.amount_minor) !== amountMinor
                    || payment.currency !== currency) {
                    const error = new Error('Payment details do not match the stored order.');
                    error.code = 'PAYMENT_MISMATCH';
                    throw error;
                }

                if (payment.status !== 'completed') {
                    await client.query(
                        `UPDATE payments
                         SET status = 'completed', provider_payment_id = $2, completed_at = NOW()
                         WHERE id = $1`,
                        [payment.id, providerPaymentId]
                    );
                    await client.query(
                        `UPDATE users
                         SET plan_expires_at = CASE
                                 WHEN current_plan = $2 AND plan_expires_at > NOW()
                                     THEN plan_expires_at + INTERVAL '30 days'
                                 ELSE NOW() + INTERVAL '30 days'
                             END,
                             current_plan = $2,
                             updated_at = NOW()
                         WHERE id = $1`,
                        [userId, planId]
                    );
                } else if (payment.provider_payment_id !== providerPaymentId) {
                    const error = new Error('Payment order was already completed with a different payment ID.');
                    error.code = 'PAYMENT_ALREADY_COMPLETED';
                    throw error;
                }

                await client.query('COMMIT');
                return { completed: true, alreadyCompleted: payment.status === 'completed' };
            } catch (error) {
                await client.query('ROLLBACK').catch(() => {});
                throw error;
            } finally {
                client.release();
            }
        },

        async listChatConversations(userId, limit = 40) {
            const result = await pool.query(
                `SELECT conversations.id,
                        conversations.title,
                        conversations.created_at,
                        conversations.updated_at,
                        COUNT(messages.id)::INTEGER AS message_count,
                        COALESCE((
                            SELECT latest.content
                            FROM chat_messages latest
                            WHERE latest.conversation_id = conversations.id
                            ORDER BY latest.created_at DESC, latest.id DESC
                            LIMIT 1
                        ), '') AS last_message
                 FROM chat_conversations conversations
                 LEFT JOIN chat_messages messages ON messages.conversation_id = conversations.id
                 WHERE conversations.user_id = $1
                 GROUP BY conversations.id
                 ORDER BY conversations.updated_at DESC, conversations.id DESC
                 LIMIT $2`,
                [userId, limit]
            );
            return result.rows;
        },

        async createChatConversation({ userId, title = 'New chat' }) {
            const result = await pool.query(
                `INSERT INTO chat_conversations (user_id, title)
                 VALUES ($1, $2)
                 RETURNING id, title, created_at, updated_at`,
                [userId, title]
            );
            return result.rows[0];
        },

        async getChatMessages({ userId, conversationId }) {
            const conversationResult = await pool.query(
                `SELECT id, title, created_at, updated_at
                 FROM chat_conversations
                 WHERE id = $1 AND user_id = $2
                 LIMIT 1`,
                [conversationId, userId]
            );
            const conversation = conversationResult.rows[0];
            if (!conversation) return null;

            const messageResult = await pool.query(
                `SELECT id, role, content, created_at
                 FROM chat_messages
                 WHERE conversation_id = $1
                 ORDER BY created_at ASC, id ASC`,
                [conversationId]
            );
            return { conversation, messages: messageResult.rows };
        },

        async getChatContext({ userId, conversationId, throughMessageId, limit = 40 }) {
            const result = await pool.query(
                `SELECT recent.id, recent.role, recent.content, recent.created_at
                 FROM (
                     SELECT messages.id, messages.role, messages.content, messages.created_at
                     FROM chat_messages messages
                     INNER JOIN chat_conversations conversations
                         ON conversations.id = messages.conversation_id
                     WHERE messages.conversation_id = $1
                       AND conversations.user_id = $2
                       AND messages.id <= $3
                     ORDER BY messages.created_at DESC, messages.id DESC
                     LIMIT $4
                 ) recent
                 ORDER BY recent.created_at ASC, recent.id ASC`,
                [conversationId, userId, throughMessageId, limit]
            );
            return result.rows;
        },

        async addChatCommand({ userId, conversationId, content, generatedTitle }) {
            const client = await pool.connect();
            try {
                await client.query('BEGIN');
                const conversationResult = await client.query(
                    `SELECT id, title
                     FROM chat_conversations
                     WHERE id = $1 AND user_id = $2
                     FOR UPDATE`,
                    [conversationId, userId]
                );
                const conversation = conversationResult.rows[0];
                if (!conversation) {
                    const error = new Error('Chat conversation was not found.');
                    error.code = 'CHAT_NOT_FOUND';
                    throw error;
                }

                const messageResult = await client.query(
                    `INSERT INTO chat_messages (conversation_id, role, content)
                     VALUES ($1, 'user', $2)
                     RETURNING id, role, content, created_at`,
                    [conversationId, content]
                );

                const nextTitle = conversation.title === 'New chat' ? generatedTitle : conversation.title;
                const updatedConversationResult = await client.query(
                    `UPDATE chat_conversations
                     SET title = $2, updated_at = NOW()
                     WHERE id = $1
                     RETURNING id, title, created_at, updated_at`,
                    [conversationId, nextTitle]
                );

                await client.query('COMMIT');
                return {
                    conversation: updatedConversationResult.rows[0],
                    message: messageResult.rows[0]
                };
            } catch (error) {
                await client.query('ROLLBACK').catch(() => {});
                throw error;
            } finally {
                client.release();
            }
        },

        async addChatAssistantResponse({ userId, conversationId, content }) {
            const client = await pool.connect();
            try {
                await client.query('BEGIN');
                const conversationResult = await client.query(
                    `SELECT id, title
                     FROM chat_conversations
                     WHERE id = $1 AND user_id = $2
                     FOR UPDATE`,
                    [conversationId, userId]
                );
                if (!conversationResult.rows[0]) {
                    const error = new Error('Chat conversation was not found.');
                    error.code = 'CHAT_NOT_FOUND';
                    throw error;
                }

                const messageResult = await client.query(
                    `INSERT INTO chat_messages (conversation_id, role, content)
                     VALUES ($1, 'assistant', $2)
                     RETURNING id, role, content, created_at`,
                    [conversationId, content]
                );
                const updatedConversationResult = await client.query(
                    `UPDATE chat_conversations
                     SET updated_at = NOW()
                     WHERE id = $1
                     RETURNING id, title, created_at, updated_at`,
                    [conversationId]
                );

                await client.query('COMMIT');
                return {
                    conversation: updatedConversationResult.rows[0],
                    message: messageResult.rows[0]
                };
            } catch (error) {
                await client.query('ROLLBACK').catch(() => {});
                throw error;
            } finally {
                client.release();
            }
        },

        async renameChatConversation({ userId, conversationId, title }) {
            const result = await pool.query(
                `UPDATE chat_conversations
                 SET title = $3, updated_at = NOW()
                 WHERE id = $1 AND user_id = $2
                 RETURNING id, title, created_at, updated_at`,
                [conversationId, userId, title]
            );
            return result.rows[0] || null;
        },

        async deleteChatConversation({ userId, conversationId }) {
            const result = await pool.query(
                `DELETE FROM chat_conversations
                 WHERE id = $1 AND user_id = $2
                 RETURNING id`,
                [conversationId, userId]
            );
            return Boolean(result.rows[0]);
        },

        async createOrFindOAuthUser({ provider, providerUserId, email, preferredUsername }) {
            const client = await pool.connect();
            try {
                await client.query('BEGIN');

                // Serialize callbacks for the same provider identity and verified email.
                await client.query('SELECT pg_advisory_xact_lock(hashtext($1))', [`oauth:${provider}:${providerUserId}`]);
                await client.query('SELECT pg_advisory_xact_lock(hashtext($1))', [`email:${email.toLowerCase()}`]);

                const existingIdentity = await findOAuthIdentity(client, provider, providerUserId);
                if (existingIdentity) {
                    await client.query('COMMIT');
                    return existingIdentity;
                }

                let user = await findUserByEmailWithClient(client, email);
                if (!user) {
                    user = await createOAuthUserWithUniqueUsername(client, {
                        email,
                        preferredUsername
                    });
                }

                const providerAlreadyLinked = await client.query(
                    `SELECT provider_user_id
                     FROM oauth_accounts
                     WHERE user_id = $1 AND provider = $2
                     LIMIT 1`,
                    [user.id, provider]
                );

                if (providerAlreadyLinked.rows[0]
                    && providerAlreadyLinked.rows[0].provider_user_id !== providerUserId) {
                    const error = new Error(`A different ${provider} identity is already linked to this user.`);
                    error.code = 'OAUTH_ACCOUNT_CONFLICT';
                    throw error;
                }

                await client.query(
                    `INSERT INTO oauth_accounts (user_id, provider, provider_user_id)
                     VALUES ($1, $2, $3)
                     ON CONFLICT (provider, provider_user_id) DO NOTHING`,
                    [user.id, provider, providerUserId]
                );

                const linkedIdentity = await findOAuthIdentity(client, provider, providerUserId);
                if (!linkedIdentity) {
                    throw new Error('OAuth identity could not be linked.');
                }

                await client.query('COMMIT');
                return linkedIdentity;
            } catch (error) {
                await client.query('ROLLBACK').catch(() => {});
                throw error;
            } finally {
                client.release();
            }
        },

        async close() {
            await pool.end();
        }
    };
}

async function findOAuthIdentity(client, provider, providerUserId) {
    const result = await client.query(
        `SELECT users.id, users.username, users.email
         FROM oauth_accounts
         INNER JOIN users ON users.id = oauth_accounts.user_id
         WHERE oauth_accounts.provider = $1
           AND oauth_accounts.provider_user_id = $2
         LIMIT 1`,
        [provider, providerUserId]
    );
    return result.rows[0] || null;
}

async function findUserByEmailWithClient(client, email) {
    const result = await client.query(
        `SELECT id, username, email
         FROM users
         WHERE LOWER(email) = LOWER($1)
         LIMIT 1`,
        [email]
    );
    return result.rows[0] || null;
}

async function createOAuthUserWithUniqueUsername(client, { email, preferredUsername }) {
    const baseUsername = sanitizeOAuthUsername(preferredUsername || email.split('@')[0]);

    for (let attempt = 0; attempt < 100; attempt += 1) {
        const username = usernameCandidate(baseUsername, attempt);
        const result = await client.query(
            `INSERT INTO users (username, email, password_hash)
             VALUES ($1, $2, NULL)
             ON CONFLICT DO NOTHING
             RETURNING id, username, email`,
            [username, email]
        );

        if (result.rows[0]) {
            return result.rows[0];
        }

        const existingEmail = await findUserByEmailWithClient(client, email);
        if (existingEmail) {
            return existingEmail;
        }
    }

    throw new Error('Unable to allocate a unique username for OAuth account.');
}

function sanitizeOAuthUsername(value) {
    let username = String(value || '')
        .normalize('NFKD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^A-Za-z0-9_]+/g, '_')
        .replace(/^_+|_+$/g, '')
        .slice(0, 32);

    if (username.length < 3) {
        username = `user_${username || 'account'}`.slice(0, 32);
    }

    return username;
}

function usernameCandidate(baseUsername, attempt) {
    if (attempt === 0) {
        return baseUsername.slice(0, 32);
    }
    const suffix = `_${attempt}`;
    return `${baseUsername.slice(0, 32 - suffix.length)}${suffix}`;
}

function parsePoolSize(value) {
    const parsed = Number.parseInt(value, 10);
    if (!Number.isInteger(parsed) || parsed < 1 || parsed > 100) {
        throw new Error('DATABASE_POOL_MAX must be a number between 1 and 100.');
    }
    return parsed;
}

module.exports = {
    createDatabaseFromEnvironment,
    createUserStore,
    sanitizeOAuthUsername,
    usernameCandidate
};
